@echo off
cd /d "%~dp0"
if exist "%LOCALAPPDATA%\Python\bin\python.exe" (
  "%LOCALAPPDATA%\Python\bin\python.exe" forge.py serve --open
) else (
  py -3 forge.py serve --open
)
pause
