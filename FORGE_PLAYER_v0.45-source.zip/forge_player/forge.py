#!/usr/bin/env python3
"""Forge Player 0.45 local library, automatic mixes and YouTube playback."""
import argparse
from contextlib import closing
import csv
import io
import html
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import secrets
import sqlite3
import threading
from urllib.parse import parse_qs,urlparse
import webbrowser
import library as lib
import importer
import youtube
from library import connect,tracks_list,summary
from legacy import video_id_from_url,iterate_likes
from importer import iterate_json_array

ROOT=Path(__file__).resolve().parent
DB_DEFAULT=ROOT/'forge_player.sqlite3'

def export_csv(con):
    f=io.StringIO(); w=csv.writer(f)
    w.writerow(['playlist','recording_id','video_id','title','artist','url','plays_90','plays_all'])
    def cell(value):
        return "'"+value if isinstance(value,str) and value.startswith(('=','+','-','@','\t','\r')) else value
    rows=lib.records(con)
    for p in lib.playlists(con):
        for r in rows:
            if p['id'] in r['memberships']:
                w.writerow([cell(v) for v in (p['name'],r['id'],r['video_id'],r['title'],r['artist'],'https://www.youtube.com/watch?v='+r['video_id'],r['plays_90'],r['plays_all'])])
    return f.getvalue()

class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,db,client):
        super().__init__(address,App)
        self.db=db; self.csrf=secrets.token_urlsafe(32); self.mutation_lock=threading.RLock()
        self.google=youtube.Google(db,client,self.server_port); self.publisher=youtube.Publisher(self.google)

class App(BaseHTTPRequestHandler):
    def log_message(self,*args): pass  # OAuth callback query strings must never enter logs.
    def host_ok(self):
        return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')
    def write(self,data,status=200,content_type='application/json; charset=utf-8'):
        body=json.dumps(data,ensure_ascii=False).encode() if content_type.startswith('application/json') else data.encode() if isinstance(data,str) else data
        self.send_response(status)
        for k,v in {'Content-Type':content_type,'Content-Length':str(len(body)),'Cache-Control':'no-store',
            'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY',
            'Content-Security-Policy':"default-src 'self'; script-src 'self' https://www.youtube.com https://s.ytimg.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-src https://www.youtube-nocookie.com https://www.youtube.com; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"}.items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if not self.host_ok(): return self.write({'error':'Unexpected host'},403)
        url=urlparse(self.path); q=parse_qs(url.query)
        try:
            if url.path=='/oauth/callback':
                try:
                    self.server.google.callback(q)
                    self.send_response(303);self.send_header('Location','/#connections');self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer');self.end_headers()
                except (ValueError,youtube.APIError) as exc:
                    detail=youtube.login_error(exc)
                    self.server.google.last_error=detail
                    self.write('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                               '<title>Forge Player — Sign-in help</title><link rel="stylesheet" href="/style.css">'
                               '<main><h1>Sign-in needs one more step</h1><p>'+html.escape(detail)+
                               '</p><p><a href="/#connections">Return to Forge Player Connections</a></p></main></html>',400,'text/html; charset=utf-8')
                return
            static={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/player.js':'player.js','/style.css':'style.css'}
            if url.path in static:
                name=static[url.path]; mime='text/html' if name.endswith('.html') else 'text/css' if name.endswith('.css') else 'text/javascript'
                return self.write((ROOT/'static'/name).read_bytes(),content_type=mime+'; charset=utf-8')
            with closing(connect(self.server.db)) as con:
                if url.path=='/api/session': result={'csrf':self.server.csrf}
                elif url.path=='/api/summary': result=summary(con)
                elif url.path=='/api/tracks': result=tracks_list(con,q.get('playlist',['ALL'])[0],q.get('q',[''])[0],q.get('sort',['popular'])[0],int(q.get('offset',[0])[0]),int(q.get('limit',[50])[0]))
                elif url.path=='/api/queue':
                    data=tracks_list(con,q.get('playlist',['FAVORITES'])[0],limit=20000)
                    rows=[r for r in data['tracks'] if r['music']]
                    result={'tracks':rows,'count':len(rows),'capped':data['total']>20000}
                elif url.path=='/api/connections': result=self.server.google.status()
                elif url.path=='/api/analytics': result=lib.analytics(con)
                elif url.path=='/api/sync': result=self.server.publisher.status(con,q.get('id',[None])[0])
                elif url.path=='/api/review': result={'candidates':lib.candidates(con),'genres':list(lib.FAMILIES),'playlists':lib.playlists(con,True)}
                elif url.path=='/api/variants':
                    result={'variants':[dict(r) for r in con.execute('SELECT t.video_id,t.title,t.artist uploader,v.evidence,count(l.event_key) plays_all FROM video_recording_links v JOIN tracks t ON t.video_id=v.video_id LEFT JOIN listens l ON l.video_id=t.video_id WHERE v.recording_id=? GROUP BY t.video_id',(q.get('id',[''])[0],))]}
                elif url.path=='/api/export': return self.write(export_csv(con),content_type='text/csv; charset=utf-8')
                else: return self.write({'error':'Not found'},404)
                self.write(result)
        except (ValueError,TypeError,KeyError,sqlite3.Error,OSError,youtube.APIError) as exc: self.write({'error':str(exc)},400)
    def do_POST(self):
        origin='http://'+self.headers.get('Host','')
        if not self.host_ok() or self.headers.get('Origin')!=origin or self.headers.get('Sec-Fetch-Site','same-origin') not in ('same-origin','none'):
            return self.write({'error':'Same-origin requests only'},403)
        if not secrets.compare_digest(self.headers.get('X-Forge-CSRF',''),self.server.csrf): return self.write({'error':'Reload the page before making changes'},403)
        if self.headers.get_content_type()!='application/json': return self.write({'error':'JSON required'},415)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=65536: raise ValueError('Invalid request size')
            data=json.loads(self.rfile.read(size))
            if not isinstance(data,dict): raise ValueError('Expected an object')
            route=urlparse(self.path).path
            with self.server.mutation_lock,closing(connect(self.server.db)) as con:
                google=self.server.google; pub=self.server.publisher
                if route=='/api/update': result=lib.update_recording(con,data)
                elif route=='/api/settings': result=lib.set_settings(con,data)
                elif route=='/api/playlist': result=lib.save_playlist(con,data)
                elif route=='/api/merge': result=lib.merge(con,data['target'],data['source'],data.get('verified') is True)
                elif route=='/api/split': result=lib.split(con,data['video_id'])
                elif route=='/api/undo': result=lib.undo(con)
                elif route=='/api/bulk-review': result=lib.bulk_review(con,data['ids'],data['status'])
                elif route=='/api/import': result=importer.import_path(con,data['path'])
                elif route=='/api/skip':
                    with con: con.execute('INSERT INTO skips(video_id) VALUES(?)',(data['video_id'],))
                    result={'ok':True}
                elif route=='/api/oauth/config':
                    source=Path(data['path']).expanduser()
                    if source.stat().st_size>65536: raise ValueError('Client file too large')
                    parsed=json.loads(source.read_text(encoding='utf-8-sig'))
                    if not parsed.get('installed',{}).get('client_id','').endswith('.apps.googleusercontent.com'): raise ValueError('Choose a Desktop client JSON')
                    google.config_path.parent.mkdir(parents=True,exist_ok=True)
                    google.config_path.write_text(json.dumps(parsed),encoding='utf-8')
                    result={'configured':True}
                elif route=='/api/oauth/start':
                    result=google.start(data.get('write') is True)
                    if data.get('open_browser',True): result['opened']=webbrowser.open(result['url'],new=2)
                elif route=='/api/oauth/likes': result=google.likes()
                elif route=='/api/oauth/enrich': result=google.enrich()
                elif route=='/api/player/alternatives': result=google.alternatives(data['recording_id'])
                elif route=='/api/player/open':
                    vid=data.get('video_id','')
                    if not isinstance(vid,str) or not importer.legacy.VIDEO_RE.fullmatch(vid): raise ValueError('Invalid YouTube video')
                    start=data.get('start',0)
                    if type(start) is not int or not 0<=start<=86400: raise ValueError('Invalid playback time')
                    result={'opened':webbrowser.open('https://www.youtube.com/watch?v='+vid+'&t='+str(start)+'s',new=2)}
                elif route=='/api/oauth/disconnect': result=google.disconnect(data.get('revoke',True) is True)
                elif route=='/api/sync/preview': result=pub.preview(con,data['playlists'],data.get('privacy','private'))
                elif route=='/api/sync/approve': result=pub.approve(con,data['id'],data['channel'])
                elif route=='/api/sync/step': result=pub.step(con,data['id'])
                elif route=='/api/sync/control': result=pub.control(con,data['id'],data['action'])
                elif route=='/api/sync/recover': result=pub.recover(con,data['id'],data['remote_id'])
                else: return self.write({'error':'Not found'},404)
                self.write(result)
        except (ValueError,TypeError,KeyError,sqlite3.Error,OSError,youtube.APIError) as exc: self.write({'error':str(exc)},400)

def main():
    parser=argparse.ArgumentParser(description='Forge Player local music library')
    parser.add_argument('--db',default=str(DB_DEFAULT))
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('init'); sub.add_parser('stats')
    imp=sub.add_parser('import');imp.add_argument('paths',nargs='+')
    exp=sub.add_parser('export');exp.add_argument('--out',default='playlist_export.csv')
    serve=sub.add_parser('serve');serve.add_argument('--port',type=int,default=8766);serve.add_argument('--open',action='store_true')
    serve.add_argument('--client',default=str(ROOT/'.private'/'google-client.json'))
    args=parser.parse_args()
    with closing(connect(args.db)) as con:
        if args.command=='init': print('Library ready: '+args.db)
        elif args.command=='stats': print(json.dumps(summary(con),indent=2))
        elif args.command=='import':
            for path in args.paths: print(json.dumps(importer.import_path(con,path),indent=2))
        elif args.command=='export': Path(args.out).write_text(export_csv(con),encoding='utf-8-sig');print('Exported '+args.out)
    if args.command=='serve':
        if not 1024<=args.port<=65535: raise SystemExit('Port must be 1024–65535')
        server=Server(('127.0.0.1',args.port),args.db,args.client)
        url=f'http://127.0.0.1:{server.server_port}/'
        print('Forge Player 0.45: '+url,flush=True)
        if args.open: webbrowser.open(url)
        try: server.serve_forever()
        except KeyboardInterrupt: pass
        finally: server.server_close()

if __name__=='__main__': main()
