"""Opt-in Google installed-app OAuth; tokens never pass through the frontend."""
import base64
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import library as lib
import importer
import classification

READ='https://www.googleapis.com/auth/youtube.readonly'
WRITE='https://www.googleapis.com/auth/youtube.force-ssl'

class APIError(Exception):
    def __init__(self, code, reason):
        self.code=code; self.reason=reason
        super().__init__(f'Google request failed ({code}: {reason}).')

def login_error(exc):
    """Actionable safe text, without OAuth responses or credentials."""
    if isinstance(exc,APIError) and exc.reason in ('accessNotConfigured','SERVICE_DISABLED'):
        return ('Google accepted sign-in, but YouTube Data API v3 is disabled in the Google Cloud project. '
                'Enable it in APIs & Services, allow a few minutes for activation, then click Log In again.')
    return str(exc)

def http(url, data=None, headers=None, method=None):
    request=urllib.request.Request(url,data=data,headers=headers or {},method=method)
    try:
        with urllib.request.urlopen(request,timeout=25) as response:
            raw=response.read(8*1024*1024)
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        reason='requestRejected'
        try:
            payload=json.loads(exc.read(65536)); error=payload.get('error',{})
            reason=error.get('errors',[{}])[0].get('reason',reason) if isinstance(error,dict) else str(error)
        except (ValueError,KeyError,IndexError): pass
        # Only a machine code, never response bodies or authorization codes/tokens.
        if not isinstance(reason,str) or not reason.replace('_','').isalnum(): reason='requestRejected'
        raise APIError(exc.code,reason) from None
    except (OSError,TimeoutError,urllib.error.URLError): raise APIError(0,'networkOutcomeUnknown') from None

def form(url, values):
    return http(url,urllib.parse.urlencode(values).encode(),{'Content-Type':'application/x-www-form-urlencoded'})

class Vault:
    """Windows user-bound DPAPI, no plaintext fallback."""
    def __init__(self,path): self.path=Path(path)
    def crypt(self,data,decrypt=False):
        if os.name!='nt': raise ValueError('OAuth token storage currently requires Windows DPAPI.')
        class Blob(ctypes.Structure):
            _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_ubyte))]
        buffer=ctypes.create_string_buffer(data)
        src=Blob(len(data),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte))); dest=Blob()
        crypt=ctypes.WinDLL('crypt32',use_last_error=True)
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.LocalFree.argtypes=[ctypes.c_void_p]; kernel.LocalFree.restype=ctypes.c_void_p
        if decrypt:
            function=crypt.CryptUnprotectData
            function.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
            ok=function(ctypes.byref(src),None,None,None,None,1,ctypes.byref(dest))
        else:
            function=crypt.CryptProtectData
            function.argtypes=[ctypes.POINTER(Blob),wintypes.LPCWSTR,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
            ok=function(ctypes.byref(src),'Forge Player',None,None,None,1,ctypes.byref(dest))
        if not ok: raise ValueError('Windows could not protect/unlock the account token. Reconnect as the original Windows user.')
        try: return ctypes.string_at(dest.pbData,dest.cbData)
        finally: kernel.LocalFree(dest.pbData)
    def read(self):
        return json.loads(self.crypt(self.path.read_bytes(),True)) if self.path.exists() else {}
    def save(self,data):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temp=self.path.with_suffix('.tmp')
        temp.write_bytes(self.crypt(json.dumps(data).encode()))
        temp.replace(self.path)
    def clear(self): self.path.unlink(missing_ok=True)

def pacific_day():
    # Current US DST rule (2007 onward); no dependency on the host timezone database.
    from datetime import datetime,timedelta,timezone
    utc=datetime.now(timezone.utc); y=utc.year
    march=datetime(y,3,8,10,tzinfo=timezone.utc); march+=timedelta(days=(6-march.weekday())%7)
    november=datetime(y,11,1,9,tzinfo=timezone.utc); november+=timedelta(days=(6-november.weekday())%7)
    return (utc+timedelta(hours=-7 if march<=utc<november else -8)).date().isoformat()

class Google:
    def __init__(self,db,config_path,port=8766,vault=None):
        self.db=db; self.config_path=Path(config_path); self.port=port
        self.vault=vault or Vault(Path(db).parent/'.private'/'google-token.dpapi')
        self.pending=None; self.lock=threading.RLock(); self.last_error=''
    def config(self):
        if not self.config_path.exists(): raise ValueError('Google setup needed: add the Desktop client JSON in Connections.')
        data=json.loads(self.config_path.read_text(encoding='utf-8-sig')).get('installed',{})
        if not data.get('client_id','').endswith('.apps.googleusercontent.com'): raise ValueError('Choose a Google Desktop OAuth client JSON file.')
        return data
    def start(self,write=False):
        config=self.config(); state=secrets.token_urlsafe(32); verifier=secrets.token_urlsafe(64)
        redirect=f'http://127.0.0.1:{self.port}/oauth/callback'
        scope=READ+(' '+WRITE if write else '')
        self.pending={'state':state,'verifier':verifier,'expires':time.time()+600,'redirect':redirect,'scope':scope}
        params={'client_id':config['client_id'],'redirect_uri':redirect,'response_type':'code','scope':scope,
                'state':state,'code_challenge':base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('='),
                'code_challenge_method':'S256','access_type':'offline','prompt':'consent select_account'}
        return {'url':'https://accounts.google.com/o/oauth2/v2/auth?'+urllib.parse.urlencode(params)}
    def callback(self,params):
        with self.lock:
            pending=self.pending
            state=params.get('state',[''])[0]
            if not pending or time.time()>pending['expires'] or not secrets.compare_digest(state,pending['state']):
                raise ValueError('Invalid or expired sign-in state. Start Log In again.')
            self.pending=None
            if params.get('error'): raise ValueError('Google authorization was declined. Your local library is unchanged.')
            code=params.get('code',[''])[0]
            if not code: raise ValueError('Missing authorization code')
            config=self.config()
            tokens=form('https://oauth2.googleapis.com/token',{'client_id':config['client_id'],'client_secret':config.get('client_secret',''),
                'code':code,'redirect_uri':pending['redirect'],'code_verifier':pending['verifier'],'grant_type':'authorization_code'})
            granted=set(tokens.get('scope','').split())
            if READ not in granted and WRITE not in granted: raise ValueError('YouTube read permission was not granted.')
            tokens['expires_at']=time.time()+tokens.get('expires_in',3600)
            tokens['scope']=' '.join(sorted(granted))
            account=self.api('channels',{'part':'snippet','mine':'true'},token=tokens['access_token'])
            if len(account.get('items',[]))!=1: raise ValueError('Select one YouTube channel and reconnect.')
            channel=account['items'][0]
            tokens['channel']={'id':channel['id'],'title':channel['snippet']['title']}
            self.vault.save(tokens); self.last_error=''
    def token(self):
        tokens=self.vault.read()
        if not tokens: raise ValueError('Log In with Google first.')
        if tokens.get('expires_at',0)<time.time()+60:
            if not tokens.get('refresh_token'): raise ValueError('Session expired; Log In again.')
            config=self.config()
            fresh=form('https://oauth2.googleapis.com/token',{'client_id':config['client_id'],'client_secret':config.get('client_secret',''),
                'refresh_token':tokens['refresh_token'],'grant_type':'refresh_token'})
            tokens.update(fresh); tokens['expires_at']=time.time()+fresh.get('expires_in',3600)
            self.vault.save(tokens)
        return tokens
    def status(self):
        try:
            data=self.vault.read()
            return {'configured':self.config_path.exists(),'connected':bool(data),'channel':data.get('channel'),
                    'scopes':data.get('scope','').split(),'can_publish':WRITE in data.get('scope','').split(),
                    'storage':'Windows DPAPI','error':self.last_error,'likes_limit':1000}
        except ValueError as exc: return {'configured':self.config_path.exists(),'connected':False,'error':str(exc)}
    def api(self,resource,params=None,body=None,method='GET',token=None):
        units=1 if method=='GET' else 50
        con=lib.connect(self.db)
        try:
            search=resource=='search'
            used=con.execute('SELECT coalesce(sum(units),0) FROM quota_ledger WHERE day=? AND '+("operation='search.list'" if search else "operation!='search.list'"),(pacific_day(),)).fetchone()[0]
            if used+units>(90 if search else 9500): raise APIError(403,'localQuotaBudgetExceeded')
            operation=resource+'.'+('list' if method=='GET' else 'insert' if method=='POST' else 'delete')
            cur=con.execute('INSERT INTO quota_ledger(day,operation,units,status) VALUES(?,?,?,?)',(pacific_day(),operation,units,'attempted')); con.commit()
            token=token or self.token()['access_token']
            try:
                result=http('https://www.googleapis.com/youtube/v3/'+resource+'?'+urllib.parse.urlencode(params or {}),
                    json.dumps(body).encode() if body is not None else None,
                    {'Authorization':'Bearer '+token,'Content-Type':'application/json'},method)
                con.execute('UPDATE quota_ledger SET status=? WHERE id=?',('success',cur.lastrowid));con.commit()
                return result
            except Exception:
                con.execute('UPDATE quota_ledger SET status=? WHERE id=?',('failed-or-unknown',cur.lastrowid));con.commit();raise
        finally: con.close()
    def verify(self):
        data=self.token(); items=self.api('channels',{'part':'snippet','mine':'true'}).get('items',[])
        if len(items)!=1 or items[0]['id']!=data['channel']['id']: raise ValueError('YouTube channel changed; reconnect and preview again.')
        return data['channel']
    def likes(self):
        self.verify(); count=0; page=None; seen=set(); added=0; con=lib.connect(self.db)
        try:
            while count<1000:
                params={'part':'snippet,topicDetails,status,contentDetails','myRating':'like','maxResults':50}
                if page: params['pageToken']=page
                response=self.api('videos',params)
                for item in response.get('items',[])[:1000-count]:
                    vid=item.get('id','')
                    if not importer.legacy.VIDEO_RE.fullmatch(vid): continue
                    added+=importer.observe_like(con,vid,'','youtube-api')
                    classification.cache(con,item)
                    count+=1
                con.commit(); page=response.get('nextPageToken')
                if not page or page in seen: break
                seen.add(page)
            with con: created=classification.ensure_playlists(con)
            report={'observed':count,'new_likes':added,'possibly_incomplete':True,'created_playlists':created,
                    'note':'API exposes at most the latest 1,000 likes. Missing results are not unlikes. YouTube music categories/topics populate local mixes; uncertain items stay in review.'}
            return report
        finally: con.close()
    def enrich(self):
        """Refresh known IDs in 50-video batches, preserving all manual curation."""
        self.verify(); con=lib.connect(self.db); observed=0; missing=0
        try:
            ids=[r[0] for r in con.execute('SELECT video_id FROM tracks ORDER BY video_id')]
            for start in range(0,len(ids),50):
                batch=ids[start:start+50]
                response=self.api('videos',{'part':'snippet,topicDetails,status,contentDetails','id':','.join(batch),'maxResults':50})
                returned={item['id'] for item in response.get('items',[])}
                with con:
                    for item in response.get('items',[]):
                        if item['id'] in batch: classification.cache(con,item); observed+=1
                    for vid in set(batch)-returned:
                        con.execute('INSERT OR REPLACE INTO api_classification VALUES(?,?,?)',(vid,json.dumps({'available':False,'embeddable':False,'genres':[]}),lib.now())); missing+=1
            with con: created=classification.ensure_playlists(con)
            rows=lib.records(con)
            return {'checked':len(ids),'available':observed,'unavailable':missing,'music':sum(bool(r['music']) for r in rows),
                    'review':sum(r['music_status']=='review' for r in rows),'artist_identified':sum(bool(r['artist']) for r in rows),
                    'created_playlists':created,'note':'YouTube topics are broad and can overlap. Manual corrections take priority. No YouTube playlists were written.'}
        finally: con.close()
    def alternatives(self,recording_id):
        con=lib.connect(self.db)
        try: track=next((r for r in lib.records(con) if r['id']==recording_id),None)
        finally: con.close()
        if not track: raise ValueError('Choose a recording from your library first.')
        query=(track['artist']+' '+track['title']).strip()[:180]
        found=self.api('search',{'part':'snippet','q':query,'type':'video','videoEmbeddable':'true',
                                'videoSyndicated':'true','maxResults':6})
        ids=[i.get('id',{}).get('videoId') for i in found.get('items',[])]
        ids=[v for v in ids if isinstance(v,str) and importer.legacy.VIDEO_RE.fullmatch(v) and v!=track['video_id']]
        result=[]
        if ids:
            details=self.api('videos',{'part':'snippet,status,contentDetails,topicDetails','id':','.join(ids)})
            for item in details.get('items',[]):
                data=classification.interpret(item)
                if data.get('embeddable') is False or data.get('age_restricted') or not data.get('available'): continue
                result.append({'video_id':item['id'],'title':item['snippet']['title'],'artist':data['artist'],
                               'uploader':item['snippet']['channelTitle'],'duration':data['duration'],
                               'playback_variants':[{'video_id':item['id'],**data}]})
        for candidate in result: candidate['automatic_match']=classification.same_song_candidate(track,candidate)
        result.sort(key=lambda candidate:not candidate['automatic_match'])
        return {'candidates':result,'query':query,'note':'Search candidates may be different versions. Try one to hear it; this does not merge recordings or change your library. Embeddable metadata is not a playback guarantee.'}
    def disconnect(self,revoke=True):
        with self.lock:
            data=self.vault.read()
            if revoke and data:
                form('https://oauth2.googleapis.com/revoke',{'token':data.get('refresh_token') or data['access_token']})
            self.vault.clear(); self.pending=None
            con=lib.connect(self.db)
            with con:
                con.execute("DELETE FROM like_observations WHERE source='youtube-api'")
                con.execute('DELETE FROM api_video_cache')
                con.execute('DELETE FROM api_classification')
                con.execute('UPDATE tracks SET is_liked=0 WHERE video_id NOT IN (SELECT video_id FROM like_observations)')
                con.execute("UPDATE sync_jobs SET status='cancelled' WHERE status NOT IN ('complete','cancelled')")
            con.close()
            return {'ok':True,'revoked':revoke}

class Publisher:
    """One explicit preview/approval; checkpoint each write; never blindly retry unknown outcomes."""
    def __init__(self,google): self.google=google; self.lock=threading.Lock()
    def remote_items(self,remote):
        items=[]; page=None; seen=set()
        while True:
            params={'part':'snippet','playlistId':remote,'maxResults':50}
            if page: params['pageToken']=page
            data=self.google.api('playlistItems',params); items.extend(data.get('items',[]))
            page=data.get('nextPageToken')
            if not page: return items
            if page in seen or len(items)>20000: raise ValueError('Remote playlist pagination is incomplete; publishing stopped.')
            seen.add(page)
    def preview(self,con,ids,privacy='private'):
        if privacy not in ('private','unlisted','public'): raise ValueError('Invalid privacy')
        if not isinstance(ids,list) or not ids or len(ids)>50: raise ValueError('Select 1–50 playlists.')
        account=self.google.verify(); ops=[]; previews=[]
        for pid in dict.fromkeys(ids):
            p=con.execute('SELECT * FROM playlists WHERE id=? AND archived=0',(pid,)).fetchone()
            if not p: raise ValueError('Playlist not found')
            remote=con.execute('SELECT remote_id FROM remote_playlists WHERE playlist_id=? AND channel_id=?',(pid,account['id'])).fetchone()
            local=lib.tracks_list(con,pid,limit=20000)
            if local['total']>20000: raise ValueError('Playlist exceeds supported 20,000 entries; narrow it first.')
            remote=remote[0] if remote else None
            items=self.remote_items(remote) if remote else []
            present={i['snippet']['resourceId']['videoId'] for i in items}
            wanted={t['video_id'] for t in local['tracks']}
            new=[t for t in local['tracks'] if t['video_id'] not in present]
            # Preview each addition; deletion is deliberately unavailable in this release.
            marker=lib.digest(account['id']+'|'+pid)[:24]
            if not remote: ops.append({'kind':'create','playlist_id':pid,'name':p['name'],'privacy':privacy,'marker':marker})
            for t in new: ops.append({'kind':'add','playlist_id':pid,'video_id':t['video_id'],'title':t['title']})
            previews.append({'id':pid,'name':p['name'],'remote_id':remote,'privacy':privacy if not remote else 'existing privacy preserved',
                             'additions':new,'remote_only_kept':len(present-wanted),'duplicate_remote_entries':len(items)-len(present),
                             'availability':'Not verified; YouTube will report inaccessible items individually.'})
        job=secrets.token_urlsafe(18)
        plan={'id':job,'channel':account,'playlists':previews,'operations':ops,'estimated_write_units':len(ops)*50,
              'estimated_minimum_read_units':1,'expires_at':time.time()+1800,'mode':'add-only; no remote removals'}
        with con:
            con.execute('INSERT INTO sync_jobs(id,plan,status) VALUES(?,?,?)',(job,json.dumps(plan),'preview'))
            con.executemany('INSERT INTO sync_operations(job_id,position,operation) VALUES(?,?,?)',[(job,i,json.dumps(op)) for i,op in enumerate(ops)])
        return plan
    def approve(self,con,job,channel):
        row=con.execute('SELECT * FROM sync_jobs WHERE id=?',(job,)).fetchone()
        if not row or row['status']!='preview': raise ValueError('Create a fresh preview first.')
        plan=json.loads(row['plan'])
        if time.time()>plan['expires_at'] or channel!=plan['channel']['id']: raise ValueError('Preview expired or account confirmation differs.')
        if WRITE not in self.google.token().get('scope','').split(): raise ValueError('Enable playlist publishing permission first.')
        if self.google.verify()['id']!=channel: raise ValueError('Account mismatch')
        with con: con.execute("UPDATE sync_jobs SET status='approved' WHERE id=?",(job,))
        return {'ok':True}
    def step(self,con,job):
        if not self.lock.acquire(blocking=False): raise ValueError('A sync operation is already running.')
        try:
            row=con.execute('SELECT * FROM sync_jobs WHERE id=?',(job,)).fetchone()
            if not row or row['status'] not in ('approved','running'): raise ValueError('Preview and approve, or resume this job, first.')
            plan=json.loads(row['plan']); account=self.google.verify()
            if account['id']!=plan['channel']['id']: raise ValueError('Channel mismatch; job stopped.')
            if WRITE not in self.google.token().get('scope','').split(): raise ValueError('Write scope missing')
            op_row=con.execute("SELECT * FROM sync_operations WHERE job_id=? AND status IN ('pending','sent') ORDER BY position LIMIT 1",(job,)).fetchone()
            if not op_row:
                failed=con.execute("SELECT count(*) FROM sync_operations WHERE job_id=? AND status='failed'",(job,)).fetchone()[0]
                with con: con.execute("UPDATE sync_jobs SET status=? WHERE id=?",('complete-with-errors' if failed else 'complete',job))
                return self.status(con,job)
            op=json.loads(op_row['operation']); pos=op_row['position']
            remote=con.execute('SELECT remote_id FROM remote_playlists WHERE playlist_id=? AND channel_id=?',(op['playlist_id'],account['id'])).fetchone()
            remote=remote[0] if remote else None
            if op['kind']=='create' and remote:
                result={'id':remote}
            elif op['kind']=='create' and op_row['status']=='sent':
                # A create may have succeeded before a crash. Never create again blindly.
                with con: con.execute("UPDATE sync_jobs SET status='needs-reconciliation' WHERE id=?",(job,))
                raise ValueError('Playlist creation outcome unknown. Inspect YouTube and use Recover playlist ID; no automatic duplicate creation.')
            else:
                if op['kind']=='add':
                    if not remote:
                        raise ValueError('Remote playlist unavailable; resolve its create operation first.')
                    matches=[i for i in self.remote_items(remote) if i['snippet']['resourceId']['videoId']==op['video_id']]
                    if matches:
                        result={'id':matches[0]['id']}
                        with con: con.execute("UPDATE sync_operations SET status='done',remote_id=? WHERE job_id=? AND position=?",(result['id'],job,pos))
                        return self.status(con,job)
                    if op_row['status']=='sent':
                        with con: con.execute("UPDATE sync_jobs SET status='needs-reconciliation' WHERE id=?",(job,))
                        raise ValueError('Previous item write outcome is uncertain. Wait and inspect YouTube before retrying from a new preview.')
                with con:
                    con.execute("UPDATE sync_jobs SET status='running' WHERE id=?",(job,))
                    con.execute("UPDATE sync_operations SET status='sent' WHERE job_id=? AND position=?",(job,pos))
                try:
                    if op['kind']=='create':
                        result=self.google.api('playlists',{'part':'snippet,status'},{'snippet':{'title':op['name'],'description':'Created by Forge Player. Forge ID: '+op['marker']},'status':{'privacyStatus':op['privacy']}},'POST')
                    else:
                        result=self.google.api('playlistItems',{'part':'snippet'},{'snippet':{'playlistId':remote,'resourceId':{'kind':'youtube#video','videoId':op['video_id']}}},'POST')
                except APIError as exc:
                    ambiguous=exc.code==0 or exc.code>=500
                    quota='quota' in exc.reason.lower() or exc.code==429
                    state='sent' if ambiguous else 'pending' if quota else 'failed'
                    with con:
                        con.execute('UPDATE sync_operations SET status=?,error=? WHERE job_id=? AND position=?',(state,str(exc),job,pos))
                        if ambiguous or quota or op['kind']=='create': con.execute("UPDATE sync_jobs SET status='paused' WHERE id=?",(job,))
                    return self.status(con,job)
            with con:
                if op['kind']=='create': con.execute('INSERT OR REPLACE INTO remote_playlists VALUES(?,?,?)',(op['playlist_id'],account['id'],result['id']))
                con.execute("UPDATE sync_operations SET status='done',remote_id=?,error=NULL WHERE job_id=? AND position=?",(result['id'],job,pos))
            return self.status(con,job)
        finally: self.lock.release()
    def status(self,con,job=None):
        if job:
            row=con.execute('SELECT * FROM sync_jobs WHERE id=?',(job,)).fetchone()
            if not row: raise ValueError('Sync job not found')
            return {'id':job,'status':row['status'],'plan':json.loads(row['plan']),
                    'operations':[dict(r) for r in con.execute('SELECT position,operation,status,remote_id,error FROM sync_operations WHERE job_id=? ORDER BY position',(job,))]}
        return {'jobs':[{'id':r['id'],'status':r['status'],'created_at':r['created_at']} for r in con.execute('SELECT * FROM sync_jobs ORDER BY created_at DESC LIMIT 20')],
                'quota_estimated_used_today':con.execute("SELECT coalesce(sum(units),0) FROM quota_ledger WHERE day=? AND operation!='search.list'",(pacific_day(),)).fetchone()[0],
                'search_calls_today':con.execute("SELECT count(*) FROM quota_ledger WHERE day=? AND operation='search.list'",(pacific_day(),)).fetchone()[0],
                'local_daily_budget':9500,'actual_project_remaining':'Unknown; shared project usage must be checked in Cloud Console.'}
    def control(self,con,job,action):
        if action not in ('pause','resume','cancel'): raise ValueError('Unknown action')
        row=con.execute('SELECT * FROM sync_jobs WHERE id=?',(job,)).fetchone()
        if not row or row['status'] in ('preview','cancelled','complete','complete-with-errors'): raise ValueError('This job cannot be controlled in its current state.')
        if row['status']=='needs-reconciliation' and action=='resume': raise ValueError('Recover the remote ID before resuming.')
        with con: con.execute('UPDATE sync_jobs SET status=? WHERE id=?',({'pause':'paused','resume':'approved','cancel':'cancelled'}[action],job))
        return self.status(con,job)
    def recover(self,con,job,remote_id):
        row=con.execute('SELECT * FROM sync_jobs WHERE id=?',(job,)).fetchone()
        if not row or row['status']!='needs-reconciliation': raise ValueError('No playlist creation to recover')
        plan=json.loads(row['plan']); account=self.google.verify()
        op_row=con.execute("SELECT * FROM sync_operations WHERE job_id=? AND status='sent' ORDER BY position LIMIT 1",(job,)).fetchone()
        op=json.loads(op_row['operation'])
        if op['kind']!='create' or plan['channel']['id']!=account['id']: raise ValueError('Cannot recover this operation by playlist ID')
        items=self.google.api('playlists',{'part':'snippet','id':remote_id}).get('items',[])
        if len(items)!=1 or items[0]['snippet']['channelId']!=account['id'] or ('Forge ID: '+op['marker']) not in items[0]['snippet'].get('description',''):
            raise ValueError('Playlist owner or Forge marker does not match this approved create operation.')
        with con:
            con.execute('INSERT OR REPLACE INTO remote_playlists VALUES(?,?,?)',(op['playlist_id'],account['id'],remote_id))
            con.execute("UPDATE sync_operations SET status='done',remote_id=? WHERE job_id=? AND position=?",(remote_id,job,op_row['position']))
            con.execute("UPDATE sync_jobs SET status='approved' WHERE id=?",(job,))
        return self.status(con,job)
