"""Bounded streaming Takeout reads, content provenance, overlap-safe event identities."""
from collections import Counter
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile
import legacy
import library as lib

MAX_FILE=1024*1024*1024
MAX_RECORD=2*1024*1024
NAMES={'watch-history.json','watch_history.json','watch-history.html','watch_history.html','likes.json','liked-videos.csv','likes.csv'}

def iterate_json_array(stream):
    decoder=json.JSONDecoder(); buf=''; pos=0; eof=False
    def fill():
        nonlocal buf,pos,eof
        buf=buf[pos:]; pos=0
        chunk=stream.read(65536)
        eof=not chunk
        buf+=chunk
        if len(buf)>MAX_RECORD: raise ValueError('JSON record exceeds 2 MiB limit')
    def space():
        nonlocal pos
        while True:
            while pos<len(buf) and buf[pos].isspace(): pos+=1
            if pos<len(buf) or eof: return
            fill()
    space()
    if pos==len(buf) or buf[pos]!='[': raise ValueError('Expected a JSON array')
    pos+=1; first=True
    while True:
        space()
        if pos<len(buf) and buf[pos]==']':
            pos+=1; space()
            if pos<len(buf): raise ValueError('Trailing content after JSON array')
            return
        if not first:
            if pos==len(buf) or buf[pos]!=',': raise ValueError('Missing JSON comma or closing bracket')
            pos+=1; space()
        if pos==len(buf): raise ValueError('Truncated JSON array')
        while True:
            try: item,end=decoder.raw_decode(buf,pos); pos=end; break
            except json.JSONDecodeError:
                if eof: raise ValueError('Malformed or truncated JSON record') from None
                fill()
        first=False
        yield item

def html_rows(stream):
    parser=legacy.HistoryHTML()
    # Use explicit-zone timestamp parsing; legacy otherwise invents UTC for local dates.
    original=legacy.normalized_time
    legacy.normalized_time=lib.normalize_time
    try:
        for chunk in iter(lambda:stream.read(65536),''):
            parser.feed(chunk)
            yield from parser.out
            parser.out.clear()
            if parser.cell and sum(map(len,parser.cell['lines']))>MAX_RECORD: raise ValueError('HTML cell exceeds 2 MiB limit')
        parser.close()
        if parser.depth: raise ValueError('Truncated HTML content cell')
    finally:
        legacy.normalized_time=original

def observe_like(con,vid,title,source='takeout'):
    con.execute('INSERT OR IGNORE INTO tracks(video_id,title,music_status) VALUES(?,?,?)',(vid,title or 'Video '+vid,'review'))
    changed=con.execute('UPDATE tracks SET is_liked=1 WHERE video_id=? AND is_liked=0',(vid,)).rowcount
    con.execute('INSERT OR REPLACE INTO like_observations VALUES(?,?,?,?)',(vid,source,lib.now(),'observed-liked; unverified-current'))
    return changed

def history(con, rows, fingerprint, origin, report):
    # Temporary SQLite counts avoid memory growth proportional to history size.
    con.execute('CREATE TEMP TABLE IF NOT EXISTS import_occurrences (base TEXT PRIMARY KEY,n INTEGER)')
    con.execute('DELETE FROM import_occurrences')
    for index,row in enumerate(rows,1):
        report['scanned']+=1
        if not isinstance(row,dict): report['skipped']+=1; continue
        vid=legacy.video_id_from_url(row.get('titleUrl'))
        title=legacy.clean_title(row.get('title'))
        if not vid or not title:
            report['skipped']+=1; continue
        if any(word in title.lower() for word in ('video that has been removed','video that is unavailable','private video','deleted video')):
            report['unavailable']+=1
        stamp=lib.normalize_time(row.get('time'))
        if stamp is None: report['missing_dates']+=1
        subtitles=row.get('subtitles') or []
        uploader=str(subtitles[0].get('name','')) if isinstance(subtitles,list) and subtitles and isinstance(subtitles[0],dict) else ''
        status=legacy.detect_music(row,uploader)
        if report['unavailable'] and any(w in title.lower() for w in ('removed','unavailable','private video','deleted video')): status='review'
        report['possible_music' if status=='music' else 'uncertain']+=1
        con.execute('INSERT OR IGNORE INTO tracks(video_id,title,artist,source,music_status) VALUES(?,?,?,?,?)',
                    (vid,title,uploader,str(row.get('header','')),status))
        if uploader.endswith(' - Topic'):
            con.execute("UPDATE recordings SET artist=?,artist_source=? WHERE id=(SELECT recording_id FROM video_recording_links WHERE video_id=?) AND manual_lock=0 AND artist=''",(uploader[:-8].strip(),'Topic channel hint; verify',vid))
        # Keep multiplicity within each file. Across overlapping files use the maximum
        # observed multiplicity; no reliable identity distinguishes same-second starts.
        if stamp: base=vid+'|'+stamp
        else: base='untimed|'+lib.digest(json.dumps(row,sort_keys=True,ensure_ascii=False))
        con.execute('INSERT INTO import_occurrences VALUES(?,1) ON CONFLICT(base) DO UPDATE SET n=n+1',(base,))
        ordinal=con.execute('SELECT n FROM import_occurrences WHERE base=?',(base,)).fetchone()[0]
        if ordinal>1: report['same_time_ambiguities']+=1
        identity=lib.digest(base+'|'+str(ordinal))
        existing=con.execute('SELECT event_key FROM event_identity WHERE identity=?',(identity,)).fetchone()
        event=existing[0] if existing else identity
        if not existing:
            con.execute('INSERT INTO listens VALUES(?,?,?,?,?)',(event,vid,stamp,origin,fingerprint))
            con.execute('INSERT INTO event_identity VALUES(?,?)',(identity,event))
            report['inserted']+=1
        else: report['duplicates']+=1
        con.execute('INSERT OR IGNORE INTO event_provenance VALUES(?,?,?,?)',(event,fingerprint,origin,index))
        report['parsed']+=1
        if index%2500==0: con.commit()

def allowed(name,archive=False):
    p=name.lower().replace('\\','/')
    if '..' in p.split('/') or p.startswith('/'): return False
    return p.split('/')[-1] in NAMES and (not archive or 'youtube' in p)

def fingerprint_stream(stream):
    h=hashlib.sha256(); count=0
    for chunk in iter(lambda:stream.read(1024*1024),b''):
        count+=len(chunk)
        if count>MAX_FILE: raise ValueError('Relevant file exceeds 1 GiB limit')
        h.update(chunk)
    return h.hexdigest()

def import_path(con,path):
    path=Path(path)
    report={k:0 for k in ('scanned','parsed','inserted','duplicates','skipped','missing_dates','unavailable','possible_music','nonmusic','uncertain','same_time_ambiguities','likes_added')}
    report.update({'path':str(path),'files':[],'errors':[],'warnings':[], 'status':'complete'})
    def entry(name,opener):
        try:
            with opener() as stream: fingerprint=fingerprint_stream(stream)
            report['files'].append({'name':name,'sha256':fingerprint})
            with opener() as raw, io.TextIOWrapper(raw,encoding='utf-8-sig',errors='strict') as stream:
                fname=name.lower().replace('\\','/').split('/')[-1]
                if fname in ('watch-history.json','watch_history.json'): history(con,iterate_json_array(stream),fingerprint,name,report)
                elif fname.endswith('.html'):
                    report['warnings'].append('HTML is best-effort; unrecognized locale/timezone dates are excluded from 90-day counts.')
                    history(con,html_rows(stream),fingerprint,name,report)
                elif fname.endswith('.csv'):
                    for row in csv.DictReader(stream):
                        report['scanned']+=1
                        vid=next((legacy.video_id_from_url(v) for v in row.values() if isinstance(v,str) and legacy.video_id_from_url(v)),None)
                        if vid: report['likes_added']+=observe_like(con,vid,row.get('Video Title') or row.get('Title') or '')
                        else: report['skipped']+=1
                else:
                    # Takeout list form streams; object wrappers are bounded explicitly.
                    head=stream.read(1); stream.seek(0)
                    if head=='[': items=iterate_json_array(stream)
                    else:
                        text=stream.read(MAX_RECORD+1)
                        if len(text)>MAX_RECORD: raise ValueError('Likes object wrapper exceeds 2 MiB; export list/CSV instead')
                        items=[json.loads(text)]
                    for row in items:
                        report['scanned']+=1
                        for vid,title in legacy.iterate_likes(row): report['likes_added']+=observe_like(con,vid,title)
            con.commit()
        except (ValueError,UnicodeError,OSError,zipfile.BadZipFile,RuntimeError) as exc:
            # Keep completed events and provenance; retries deduplicate them.
            con.commit()
            report['errors'].append({'file':name,'type':type(exc).__name__,'message':str(exc)[:250]})
            report['status']='partial'
    try:
        if path.is_dir():
            files=[p for p in path.rglob('*') if p.is_file() and allowed(p.name)]
            for p in files:
                if p.suffix=='.html' and p.with_suffix('.json').exists(): continue
                entry(str(p),lambda p=p:p.open('rb'))
        elif zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as z:
                infos=z.infolist(); names={i.filename for i in infos}
                total=0
                for i in infos:
                    if i.is_dir() or not allowed(i.filename,True): continue
                    if i.filename.endswith('.html') and i.filename[:-5]+'.json' in names: continue
                    total+=i.file_size
                    if i.file_size>MAX_FILE or i.file_size>max(i.compress_size,1)*1000 or total>4*MAX_FILE:
                        report['errors'].append({'file':i.filename,'type':'ArchiveLimit','message':'Size/expansion safety limit exceeded'})
                        report['status']='partial'; continue
                    entry(i.filename,lambda i=i:z.open(i))
        elif allowed(path.name): entry(str(path),lambda:path.open('rb'))
        else: raise ValueError('Choose Takeout ZIP, folder, watch-history JSON/HTML, or likes JSON/CSV')
    except (OSError,ValueError,zipfile.BadZipFile) as exc:
        report['errors'].append({'type':type(exc).__name__,'message':str(exc)[:250]}); report['status']='partial'
    if not report['files']: report['warnings'].append('No supported YouTube files read; no complete import is claimed.')
    if report['same_time_ambiguities']: report['warnings'].append('Same-time starts retain maximum per-file multiplicity; cross-file identity cannot be proven.')
    if report['missing_dates']: report['warnings'].append('Untimed events are excluded from recent counts; identical untimed rows across exports may represent different starts.')
    con.execute('INSERT INTO import_reports(report) VALUES(?)',(json.dumps(report),)); con.commit()
    return report
