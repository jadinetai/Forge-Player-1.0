"""Repeatable synthetic import/query benchmark; never touches the default library."""
import json
from pathlib import Path
import sys
import tempfile
import time
from datetime import datetime,timedelta,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import library as lib
import importer

def run():
    with tempfile.TemporaryDirectory() as folder:
        root=Path(folder);path=root/'watch-history.json';con=lib.connect(root/'benchmark.sqlite3')
        try:
            base=datetime.now(timezone.utc)-timedelta(days=2)
            with path.open('w',encoding='utf8') as f:
                f.write('[')
                for i in range(25000):
                    if i:f.write(',')
                    json.dump({'title':'Listened to Synthetic Song '+str(i%5000),'header':'YouTube Music',
                               'titleUrl':'https://music.youtube.com/watch?v='+f'{i%5000:011d}',
                               'time':(base+timedelta(seconds=i)).isoformat(),
                               'subtitles':[{'name':'Synthetic Artist '+str(i%100)+' - Topic'}]},f)
                f.write(']')
            start=time.perf_counter();report=importer.import_path(con,path);import_seconds=time.perf_counter()-start
            start=time.perf_counter();repeat=importer.import_path(con,path);repeat_seconds=time.perf_counter()-start
            start=time.perf_counter();summary=lib.summary(con);summary_seconds=time.perf_counter()-start
            start=time.perf_counter();page=lib.tracks_list(con,'FAVORITES',limit=50);query_seconds=time.perf_counter()-start
            assert report['inserted']==25000 and repeat['inserted']==0 and summary['recordings']==5000 and page['total']==5000
            return {'data':'SYNTHETIC ONLY','events':25000,'videos':5000,'recordings':5000,'favorites':5000,
                    'reimport_new_events':repeat['inserted'],'page_size':len(page['tracks']),
                    'import_seconds':round(import_seconds,3),'reimport_seconds':round(repeat_seconds,3),
                    'summary_seconds':round(summary_seconds,3),'favorites_page_seconds':round(query_seconds,3)}
        finally:con.close()
if __name__=='__main__':print(json.dumps(run(),indent=2))
