import io
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
import zipfile
from datetime import datetime,timedelta,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import library as lib
import importer
import forge

class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.db=self.root/'test.sqlite3';self.con=lib.connect(self.db)
    def tearDown(self): self.con.close();self.tmp.cleanup()
    def row(self,vid='AbCdef123_-',days=1,title='Song',source='YouTube Music',time=None):
        return {'title':'Watched '+title,'header':source,'titleUrl':'https://www.youtube.com/watch?v='+vid,
                'time':time or (datetime.now(timezone.utc)-timedelta(days=days)).isoformat(),'subtitles':[{'name':'Artist - Topic'}]}
    def ingest(self,rows,name='watch-history.json'):
        p=self.root/name;p.write_text(json.dumps(rows),encoding='utf-8');return importer.import_path(self.con,p)
    def add(self,vid,count=5,days=1,title='Song'):
        base=datetime.now(timezone.utc)-timedelta(days=days)
        return self.ingest([self.row(vid,title=title,time=(base+timedelta(seconds=i)).isoformat()) for i in range(count)])
    def test_reimport_and_source_change_overlap(self):
        rows=[self.row(time='2026-10-01T01:00:00Z'),self.row(time='2026-10-01T01:00:01Z')]
        self.assertEqual(self.ingest(rows)['inserted'],2)
        self.assertEqual(self.ingest(rows)['duplicates'],2)
        rows[0]['header']='YouTube';rows.append(self.row(time='2026-10-01T01:00:02Z'))
        self.assertEqual(self.ingest(rows)['inserted'],1)
        self.assertEqual(self.con.execute('SELECT count(*) FROM listens').fetchone()[0],3)
    def test_same_second_multiplicity_microseconds_and_missing(self):
        a=self.row(time='2026-10-01T01:00:00.001Z');b=self.row(time='2026-10-01T01:00:00.002Z');c=self.row();c.pop('time')
        r=self.ingest([a,a,b,c]);self.assertEqual(r['inserted'],4);self.assertEqual(r['same_time_ambiguities'],1)
        self.assertEqual(self.ingest([a,a,b,c])['inserted'],0)
        self.assertEqual(lib.summary(self.con)['timeless_events'],1)
    def test_zip_renamed_overlap_and_allowlist(self):
        row=self.row();p=self.root/'part.zip'
        with zipfile.ZipFile(p,'w') as z:
            z.writestr('Takeout/YouTube/history/watch-history.json',json.dumps([row]))
            z.writestr('Takeout/Other/watch-history.json',json.dumps([self.row('AbCdef123_A')]))
            z.writestr('../YouTube/watch-history.json',json.dumps([self.row('AbCdef123_B')]))
        self.assertEqual(importer.import_path(self.con,p)['inserted'],1)
        q=self.root/'renamed.zip';q.write_bytes(p.read_bytes());self.assertEqual(importer.import_path(self.con,q)['inserted'],0)
    def test_malformed_partial_and_restart(self):
        p=self.root/'watch-history.json';p.write_text('['+json.dumps(self.row())+', {bad')
        r=importer.import_path(self.con,p);self.assertEqual(r['status'],'partial');self.assertEqual(r['inserted'],1)
        self.assertEqual(importer.import_path(self.con,p)['inserted'],0)
        for bad in ('[{},]','[{}{}]','[{}','[1] garbage'):
            with self.assertRaises(ValueError):list(importer.iterate_json_array(io.StringIO(bad)))
    def test_large_stream_and_bad_encoding(self):
        data='['+','.join(json.dumps({'x':'a'*500}) for _ in range(12000))+']'
        self.assertEqual(sum(1 for _ in importer.iterate_json_array(io.StringIO(data))),12000)
        p=self.root/'watch-history.json';p.write_bytes(b'[\xff]');r=importer.import_path(self.con,p);self.assertEqual(r['status'],'partial')
    def test_timezones_and_non_us_locale(self):
        self.assertEqual(lib.normalize_time('Oct 1, 2026, 1:00:00 PM EDT'),'2026-10-01T17:00:00.000000+00:00')
        self.assertIsNone(lib.normalize_time('2026-10-01 13:00:00'))
        self.assertIsNone(lib.normalize_time('1 octobre 2026 à 13:00:00'))
        html='<div class="content-cell"><a href="https://youtube.com/watch?v=AbCdef123_-">Watched Song</a><br>Artist<br>1 octobre 2026 à 13:00:00</div>'
        p=self.root/'watch-history.html';p.write_text(html,encoding='utf8');r=importer.import_path(self.con,p)
        self.assertEqual(r['missing_dates'],1);self.assertTrue(r['warnings'])
    def test_favorites_boundaries_and_expiry(self):
        for i,n in enumerate((1,4,5,15,20,50)):
            self.add('AbCdef123_'+str(i),n)
        self.add('AbCdef123_X',15,days=120)
        for threshold,expected in ((1,6),(5,4),(15,3),(20,2),(50,1)):
            lib.set_settings(self.con,{'favorite_threshold':threshold,'liked_favorites':False})
            self.assertEqual(lib.tracks_list(self.con,'FAVORITES')['total'],expected)
        lib.update_recording(self.con,{'recording_id':'AbCdef123_X','favorite_override':1})
        lib.update_recording(self.con,{'recording_id':'AbCdef123_5','favorite_override':0})
        self.assertEqual(lib.tracks_list(self.con,'FAVORITES')['total'],1)
    def test_likes_not_music_and_opt_in_favorites(self):
        importer.observe_like(self.con,'AbCdef123_-','Engineering tutorial');self.con.commit()
        lib.set_settings(self.con,{'favorite_threshold':5,'liked_favorites':True})
        self.assertEqual(lib.tracks_list(self.con,'FAVORITES')['total'],0)
        lib.update_recording(self.con,{'recording_id':'AbCdef123_-','music_status':'music'})
        self.assertEqual(lib.tracks_list(self.con,'FAVORITES')['total'],1)
        lib.update_recording(self.con,{'recording_id':'AbCdef123_-','favorite_override':0})
        importer.observe_like(self.con,'AbCdef123_-','New title');self.con.commit()
        self.assertEqual(lib.tracks_list(self.con,'FAVORITES')['total'],0)
    def test_merge_split_undo_preserves_every_listen(self):
        self.add('AbCdef123_A',3);self.add('AbCdef123_B',3);self.add('AbCdef123_C',2,title='Song (Live)')
        self.assertEqual(len(lib.candidates(self.con)),1)
        lib.merge(self.con,'AbCdef123_A','AbCdef123_B',True)
        self.assertEqual(lib.tracks_list(self.con,'FAVORITES')['tracks'][0]['plays_all'],6)
        lib.split(self.con,'AbCdef123_B');self.assertEqual(lib.tracks_list(self.con,'ALL')['total'],3)
        lib.undo(self.con);self.assertEqual(lib.tracks_list(self.con,'ALL')['total'],2)
        self.assertEqual(lib.summary(self.con)['total_events'],8)
    def test_artist_channel_manual_genres_multiplaylist(self):
        r=self.row();r['subtitles']=[{'name':'Uploader Corporation'}];self.ingest([r])
        rec=lib.records(self.con)[0];self.assertEqual(rec['artist'],'');self.assertEqual(rec['uploader'],'Uploader Corporation')
        pid=lib.save_playlist(self.con,{'name':'Night drives','kind':'manual'})['id']
        lib.update_recording(self.con,{'recording_id':rec['id'],'artist':'Real performer','genres':['Punk','Phonk'],'memberships':{pid:1}})
        self.ingest([r]);self.assertEqual(lib.records(self.con)[0]['artist'],'Real performer')
        self.assertEqual(set(lib.records(self.con)[0]['memberships']),{'ROCK','HIPHOP',pid})
        self.assertEqual(len(lib.records(self.con)[0]['genres']),2)
    def test_migration_backup_preserves_choices(self):
        old=self.root/'old.sqlite3';c=sqlite3.connect(old);c.executescript((lib.ROOT/'schema.sql').read_text())
        c.execute("INSERT INTO tracks(video_id,title,artist,favorite_override,is_emotional,is_liked) VALUES('AbCdef123_-','Old','Uploader',0,1,1)")
        c.execute("INSERT INTO listens VALUES('old','AbCdef123_-','2026-10-01T01:00:00+00:00','file','batch')")
        c.execute("INSERT INTO skips(video_id) VALUES('AbCdef123_-')");c.commit();c.close()
        c=lib.connect(old)
        try:
            self.assertEqual(c.execute('PRAGMA user_version').fetchone()[0],5)
            self.assertEqual(c.execute('SELECT count(*) FROM listens').fetchone()[0],1)
            self.assertEqual(c.execute("SELECT included FROM memberships WHERE playlist_id='FAVORITES'").fetchone()[0],0)
            self.assertEqual(c.execute('SELECT count(*) FROM like_observations').fetchone()[0],1)
        finally:c.close()
        self.assertEqual(len(list(self.root.glob('old.sqlite3.pre-v02-*.bak'))),1)
    def test_id_and_csv_formula_safety(self):
        self.assertIsNone(forge.video_id_from_url('https://evil.test/watch?v=AbCdef123_-'))
        self.add('AbCdef123_-',5,title='=FORMULA')
        self.assertIn("'=FORMULA",forge.export_csv(self.con))
    def test_bulk_review_undo(self):
        self.add('AbCdef123_A',1);self.add('AbCdef123_B',1)
        lib.bulk_review(self.con,['AbCdef123_A','AbCdef123_B'],'not_music')
        self.assertEqual(lib.summary(self.con)['music_tracks'],0)
        lib.undo(self.con);self.assertEqual(lib.summary(self.con)['music_tracks'],2)
        with self.assertRaises(ValueError):lib.bulk_review(self.con,['AbCdef123_A','missing'],'not_music')
        self.assertEqual(lib.summary(self.con)['music_tracks'],2)

if __name__=='__main__':unittest.main()
