// Offline behavioral tests of the player controller, with a fake official API.
const assert=require('node:assert/strict');
global.setInterval=()=>0;
function element(){return {textContent:'',disabled:false,value:0,children:[],append(...items){this.children.push(...items);},appendChild(item){this.children.push(item);},replaceChildren(...items){this.children=items;}};}
global.document={createElement:element,activeElement:null};
global.location={origin:'http://127.0.0.1:8766',href:'http://127.0.0.1:8766/'};
const players=[];
global.YT={Player:class {
  constructor(iframe,options){this.iframe=iframe;this.events=options.events;this.state=2;players.push(this);}
  playVideo(){this.state=1;this.events.onStateChange({data:1});}
  pauseVideo(){this.state=2;this.events.onStateChange({data:2});}
  getPlayerState(){return this.state;}
  getDuration(){return 192;}
  getCurrentTime(){return 17;}
  seekTo(value){this.seek=value;}
  destroy(){this.destroyed=true;}
}};
global.window={YT};
const {Player,clock}=require('../static/player.js');
function fixture(){const els={container:element(),status:element(),time:element(),seek:element(),pause:element()};return {p:new Player(els),...els};}
(async()=>{
  assert.equal(clock(65),'1:05');assert.equal(clock(3661),'1:01:01');
  const f=fixture();await f.p.play({title:'Synthetic song',video_id:'AbCdef123_-'});const first=players.at(-1);
  assert.match(first.iframe.src,/enablejsapi=1/);assert.match(first.iframe.src,/origin=http/);
  assert.equal(first.iframe.referrerPolicy,'strict-origin-when-cross-origin');
  first.events.onReady({target:first});assert.equal(f.status.textContent,'Playing');
  f.p.tick();assert.equal(f.time.textContent,'0:17 / 3:12');
  f.pause.onclick();assert.equal(first.state,2);f.seek.value=50;f.seek.onchange();assert.equal(first.seek,50);
  first.events.onError({data:150});assert.match(f.status.textContent,/150/);assert.equal(f.pause.disabled,true);assert.equal(f.p.ready,false);assert.equal(first.destroyed,true);
  assert.match(f.container.children[0].children[2].textContent,/Play on YouTube/);
  const r=fixture();await r.p.play({title:'Known variants',video_id:'AbCdef123_-',playback_variants:[{video_id:'AbCdef123_-',embeddable:false},{video_id:'AbCdef123_A',embeddable:true}]});
  assert.equal(r.p.videoId,'AbCdef123_A');
  const a=fixture();await a.p.play({title:'Restricted',playback_variants:[{video_id:'AbCdef123_-',age_restricted:true,duration:90}]});
  assert.match(a.status.textContent,/age verification/);assert.equal(a.time.textContent,'— / 1:30');
  const rapid=fixture();const pending=rapid.p.play({title:'Old',video_id:'AbCdef123_-'});rapid.p.stop();await pending;assert.equal(rapid.container.children.length,0);
  console.log('Player checks passed: origin/referrer, real API clock, play/pause/seek, error 150 fallback, variant selection, age restriction, stale load cancellation.');
})().catch(error=>{console.error(error);process.exitCode=1;});
