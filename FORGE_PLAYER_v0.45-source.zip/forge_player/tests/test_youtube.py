import http.client
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import forge
import library as lib
import youtube as yt

class MemoryVault:
    def __init__(self):self.data={}
    def read(self):return dict(self.data)
    def save(self,data):self.data=dict(data)
    def clear(self):self.data={}

class OAuthTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.db=self.root/'db.sqlite3';self.con=lib.connect(self.db)
        self.config=self.root/'client.json';self.config.write_text(json.dumps({'installed':{'client_id':'test.apps.googleusercontent.com'}}))
        self.vault=MemoryVault();self.google=yt.Google(self.db,self.config,vault=self.vault)
    def tearDown(self):self.con.close();self.tmp.cleanup()
    def test_state_pkce_replay_and_token_redaction(self):
        url=self.google.start()['url'];self.assertIn('code_challenge_method=S256',url);state=self.google.pending['state']
        with self.assertRaises(ValueError):self.google.callback({'state':['wrong'],'code':['x']})
        with patch.object(yt,'form',return_value={'access_token':'SECRET','refresh_token':'REFRESH','scope':yt.READ}),patch.object(self.google,'api',return_value={'items':[{'id':'channel','snippet':{'title':'Test'}}]}):
            self.google.callback({'state':[state],'code':['x']})
        self.assertNotIn('SECRET',json.dumps(self.google.status()));self.assertNotIn('REFRESH',json.dumps(self.google.status()))
        with self.assertRaises(ValueError):self.google.callback({'state':[state],'code':['x']})
    def test_dpapi_roundtrip(self):
        vault=yt.Vault(self.root/'token.dpapi');vault.save({'refresh_token':'PRIVATE-VALUE'})
        self.assertNotIn(b'PRIVATE-VALUE',vault.path.read_bytes());self.assertEqual(vault.read()['refresh_token'],'PRIVATE-VALUE');vault.clear()
    def test_disabled_api_does_not_store_unverified_account(self):
        self.google.start(); state=self.google.pending['state']
        with patch.object(yt,'form',return_value={'access_token':'SECRET','scope':yt.READ}),patch.object(self.google,'api',side_effect=yt.APIError(403,'accessNotConfigured')):
            with self.assertRaises(yt.APIError) as caught:self.google.callback({'state':[state],'code':['x']})
        self.assertFalse(self.vault.read())
        detail=yt.login_error(caught.exception)
        self.assertIn('Enable it in APIs & Services',detail);self.assertNotIn('SECRET',detail)
        self.assertIsNone(self.google.pending)
    def test_likes_pagination_cap_preserves_prior(self):
        self.con.execute("INSERT INTO tracks(video_id,title,is_liked) VALUES('AbCdef123_-','Prior',1)");self.con.commit()
        page=0
        def api(*args,**kwargs):
            nonlocal page
            page+=1
            return {'items':[{'id':f'{page:03d}{n:08d}'} for n in range(50)],'nextPageToken':str(page)}
        with patch.object(self.google,'verify',return_value={'id':'channel'}),patch.object(self.google,'api',side_effect=api):r=self.google.likes()
        self.assertEqual(page,20);self.assertEqual(r['observed'],1000);self.assertTrue(r['possibly_incomplete'])
        self.assertEqual(self.con.execute('SELECT count(*) FROM tracks WHERE is_liked=1').fetchone()[0],1001)
    def test_disconnect_revocation_failure_retains_token(self):
        self.vault.save({'access_token':'TOKEN'})
        with patch.object(yt,'form',side_effect=yt.APIError(0,'networkOutcomeUnknown')):
            with self.assertRaises(yt.APIError):self.google.disconnect()
        self.assertTrue(self.vault.read())
        with patch.object(yt,'form',return_value={}):self.google.disconnect()
        self.assertFalse(self.vault.read())
    def test_alternatives_are_candidates_without_library_mutation(self):
        self.con.execute("INSERT INTO tracks(video_id,title) VALUES('AbCdef123_-','Artist - Song')");self.con.commit()
        before=lib.edit_snapshot(self.con)
        responses=[{'items':[{'id':{'videoId':'AbCdef123_A'}},{'id':{'videoId':'AbCdef123_B'}}]},
                   {'items':[{'id':'AbCdef123_A','snippet':{'title':'Song','channelTitle':'Uploader'},'status':{'embeddable':True,'privacyStatus':'public'}},
                             {'id':'AbCdef123_B','snippet':{'title':'Restricted','channelTitle':'Uploader'},'status':{'embeddable':False,'privacyStatus':'public'}}]}]
        with patch.object(self.google,'api',side_effect=responses) as api:
            result=self.google.alternatives('AbCdef123_-')
        self.assertEqual(len(result['candidates']),1)
        self.assertEqual(api.call_args_list[0].args[1]['videoEmbeddable'],'true')
        self.assertEqual(lib.edit_snapshot(self.con),before)
        self.assertEqual(self.con.execute('SELECT count(*) FROM tracks').fetchone()[0],1)
    def test_local_origin_host_csrf(self):
        server=forge.Server(('127.0.0.1',0),self.db,self.config);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            port=server.server_port
            def post(headers):
                c=http.client.HTTPConnection('127.0.0.1',port);c.request('POST','/api/settings',json.dumps({'favorite_threshold':15,'liked_favorites':False}),headers);r=c.getresponse();status=r.status;r.read();c.close();return status
            h={'Content-Type':'application/json','Origin':f'http://127.0.0.1:{port}','X-Forge-CSRF':server.csrf}
            self.assertEqual(post(h),200)
            self.assertEqual(post({**h,'Origin':'https://evil.test'}),403)
            self.assertEqual(post({**h,'X-Forge-CSRF':'bad'}),403)
            self.assertEqual(post({**h,'Host':'evil.test'}),403)
        finally:server.shutdown();server.server_close();thread.join()

class FakeGoogle:
    def __init__(self):self.writes=[];self.remote={};self.fail=None;self.scopes=yt.READ+' '+yt.WRITE
    def token(self):return {'scope':self.scopes}
    def verify(self):return {'id':'channel','title':'Synthetic test channel'}
    def api(self,resource,params=None,body=None,method='GET'):
        if method=='GET':return {'items':self.remote.get(params.get('playlistId'),[])}
        if self.fail:
            error=self.fail;self.fail=None;raise error
        self.writes.append((resource,body));ident='remote'+str(len(self.writes))
        if resource=='playlistItems':self.remote.setdefault(body['snippet']['playlistId'],[]).append({'id':ident,'snippet':body['snippet']})
        return {'id':ident}

class PublishTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=Path(self.tmp.name)/'db.sqlite3';self.con=lib.connect(self.db)
        self.google=FakeGoogle();self.pub=yt.Publisher(self.google)
        self.con.execute("INSERT INTO tracks(video_id,title,music_status) VALUES('AbCdef123_-','Synthetic Song','music')")
        self.con.execute("INSERT INTO memberships VALUES('FAVORITES','AbCdef123_-',1)");self.con.commit()
    def tearDown(self):self.con.close();self.tmp.cleanup()
    def preview(self):return self.pub.preview(self.con,['FAVORITES'])
    def finish(self,job):
        for _ in range(10):
            r=self.pub.step(self.con,job)
            if r['status'] in ('complete','complete-with-errors'):return r
        self.fail('Job failed to complete')
    def test_no_write_before_approval_scope_account(self):
        p=self.preview()
        with self.assertRaises(ValueError):self.pub.step(self.con,p['id'])
        self.google.scopes=yt.READ
        with self.assertRaises(ValueError):self.pub.approve(self.con,p['id'],'channel')
        self.google.scopes=yt.WRITE
        with self.assertRaises(ValueError):self.pub.approve(self.con,p['id'],'other-channel')
        self.assertEqual(self.google.writes,[])
    def test_quota_private_and_idempotent(self):
        p=self.pub.preview(self.con,['ELECTRONIC','ROCK','HIPHOP','FAVORITES','EMOTIONAL'])
        self.assertEqual(p['estimated_write_units'],300)
        self.pub.approve(self.con,p['id'],'channel');self.finish(p['id'])
        for resource,body in self.google.writes:
            if resource=='playlists':self.assertEqual(body['status']['privacyStatus'],'private')
        q=self.preview();self.assertEqual(q['operations'],[])
    def test_quota_pause_resume_success_checkpoint(self):
        p=self.preview();self.pub.approve(self.con,p['id'],'channel');self.pub.step(self.con,p['id'])
        self.google.fail=yt.APIError(403,'quotaExceeded');r=self.pub.step(self.con,p['id']);self.assertEqual(r['status'],'paused')
        self.pub.control(self.con,p['id'],'resume');self.finish(p['id']);self.assertEqual(len(self.google.writes),2)
    def test_crash_unknown_create_never_duplicates(self):
        p=self.preview();self.pub.approve(self.con,p['id'],'channel');self.google.fail=yt.APIError(0,'networkOutcomeUnknown')
        self.pub.step(self.con,p['id']);self.pub.control(self.con,p['id'],'resume')
        with self.assertRaises(ValueError):self.pub.step(self.con,p['id'])
        self.assertEqual(self.pub.status(self.con,p['id'])['status'],'needs-reconciliation');self.assertEqual(self.google.writes,[])
    def test_item_failure_is_reported(self):
        p=self.preview();self.pub.approve(self.con,p['id'],'channel');self.pub.step(self.con,p['id']);self.google.fail=yt.APIError(404,'videoNotFound')
        self.pub.step(self.con,p['id']);r=self.finish(p['id']);self.assertEqual(r['operations'][1]['status'],'failed')
    def test_sent_add_reconciles_success_without_repeat(self):
        p=self.preview();self.pub.approve(self.con,p['id'],'channel');self.pub.step(self.con,p['id']);self.pub.step(self.con,p['id'])
        self.con.execute("UPDATE sync_operations SET status='sent' WHERE job_id=? AND position=1",(p['id'],));self.con.commit()
        self.finish(p['id']);self.assertEqual(len(self.google.writes),2)

if __name__=='__main__':unittest.main()
