CREATE TABLE recordings (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, artist TEXT NOT NULL DEFAULT '',
 artist_source TEXT NOT NULL DEFAULT 'unknown', manual_lock INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE video_recording_links (
 video_id TEXT PRIMARY KEY REFERENCES tracks(video_id),
 recording_id TEXT NOT NULL REFERENCES recordings(id), evidence TEXT NOT NULL DEFAULT 'separate upload'
);
CREATE INDEX recording_links_idx ON video_recording_links(recording_id);
CREATE TABLE genres (name TEXT PRIMARY KEY, family TEXT);
CREATE TABLE recording_genres (
 recording_id TEXT REFERENCES recordings(id), genre TEXT REFERENCES genres(name),
 source TEXT NOT NULL, confidence REAL NOT NULL, manual_lock INTEGER NOT NULL DEFAULT 1,
 PRIMARY KEY(recording_id,genre)
);
CREATE TABLE playlists (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL, kind TEXT NOT NULL,
 rule TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL, archived INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE memberships (
 playlist_id TEXT REFERENCES playlists(id), recording_id TEXT REFERENCES recordings(id),
 included INTEGER NOT NULL CHECK(included IN(0,1)), PRIMARY KEY(playlist_id,recording_id)
);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE event_identity (identity TEXT PRIMARY KEY, event_key TEXT REFERENCES listens(event_key));
CREATE TABLE import_reports (id INTEGER PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP, report TEXT NOT NULL);
CREATE TABLE event_provenance (event_key TEXT REFERENCES listens(event_key), fingerprint TEXT, origin TEXT, row_number INTEGER,
 PRIMARY KEY(event_key,fingerprint,origin,row_number));
CREATE TABLE like_observations (video_id TEXT REFERENCES tracks(video_id), source TEXT, observed_at TEXT, state TEXT,
 PRIMARY KEY(video_id,source));
CREATE TABLE edits (id INTEGER PRIMARY KEY, action TEXT NOT NULL, before_state TEXT NOT NULL, after_state TEXT NOT NULL,
 undone INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE remote_playlists (playlist_id TEXT REFERENCES playlists(id), channel_id TEXT NOT NULL, remote_id TEXT NOT NULL,
 PRIMARY KEY(playlist_id,channel_id));
CREATE TABLE sync_jobs (id TEXT PRIMARY KEY, plan TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE sync_operations (job_id TEXT REFERENCES sync_jobs(id), position INTEGER, operation TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', remote_id TEXT, error TEXT, PRIMARY KEY(job_id,position));
CREATE TABLE quota_ledger (id INTEGER PRIMARY KEY, day TEXT NOT NULL, operation TEXT NOT NULL, units INTEGER NOT NULL,
 status TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
INSERT INTO recordings(id,title,artist,artist_source)
 SELECT video_id,title,CASE WHEN artist LIKE '% - Topic' THEN substr(artist,1,length(artist)-8) ELSE '' END,
 CASE WHEN artist LIKE '% - Topic' THEN 'Topic channel hint; verify' ELSE 'unknown; uploader preserved separately' END FROM tracks;
INSERT INTO video_recording_links(video_id,recording_id) SELECT video_id,video_id FROM tracks;
CREATE TRIGGER track_identity AFTER INSERT ON tracks BEGIN
 INSERT INTO recordings(id,title) VALUES(NEW.video_id,NEW.title);
 INSERT INTO video_recording_links(video_id,recording_id) VALUES(NEW.video_id,NEW.video_id);
END;
CREATE TABLE api_video_cache (video_id TEXT PRIMARY KEY REFERENCES tracks(video_id),title TEXT,uploader TEXT,fetched_at TEXT NOT NULL);
CREATE TABLE api_classification (video_id TEXT PRIMARY KEY REFERENCES tracks(video_id),data TEXT NOT NULL,fetched_at TEXT NOT NULL);
CREATE TABLE genre_locks (recording_id TEXT PRIMARY KEY REFERENCES recordings(id));
PRAGMA user_version=5;
