'use strict';
// The official visible YouTube player owns all audiovisual playback.
const ForgePlayback = (() => {
  const errors = {
    2:'This video ID is invalid.',
    5:'YouTube could not play this video in this browser. Try your default browser.',
    100:'This video was removed, made private, or is unavailable to this viewer.',
    101:'The owner does not allow this video to play in an embedded player.',
    150:'YouTube does not allow this video to play here. It may require viewing on YouTube.',
    153:'YouTube could not identify the player origin. Reload Forge, or use your default browser.'
  };
  let apiPromise;
  function loadAPI() {
    if (window.YT?.Player) return Promise.resolve();
    if (apiPromise) return apiPromise;
    apiPromise = new Promise((resolve,reject) => {
      const timeout=setTimeout(()=>{apiPromise=null;reject(Error('YouTube player did not respond. Check the network or open the video in your default browser.'));},15000);
      window.onYouTubeIframeAPIReady=()=>{clearTimeout(timeout);resolve();};
      const tag=document.createElement('script'); tag.src='https://www.youtube.com/iframe_api';
      tag.referrerPolicy='strict-origin-when-cross-origin';
      tag.onerror=()=>{clearTimeout(timeout);apiPromise=null;tag.remove();reject(Error('The YouTube player script was blocked or could not load.'));};
      document.head.appendChild(tag);
    });
    return apiPromise;
  }
  function clock(seconds) {
    seconds=Math.max(0,Math.floor(Number(seconds)||0));
    return (seconds>=3600?Math.floor(seconds/3600)+':':'')+String(Math.floor(seconds/60)%60).padStart(seconds>=3600?2:1,'0')+':'+String(seconds%60).padStart(2,'0');
  }
  class Player {
    constructor({container,status,time,seek,pause,onEnded,onVideo,onUnavailable}) {
      Object.assign(this,{container,status,time,seek,pause,onEnded,onVideo,onUnavailable});
      this.generation=0; this.instance=null; this.ready=false; this.failed=false; this.variants=[]; this.position=0;
      this.timer=setInterval(()=>this.tick(),500);
      pause.onclick=()=>{if(!this.ready)return;this.instance.getPlayerState()===1?this.instance.pauseVideo():this.instance.playVideo();};
      seek.onchange=()=>{if(this.ready)this.instance.seekTo(Number(seek.value),true);};
    }
    setStatus(text){this.status.textContent=text;}
    stop(){this.generation++;this.ready=false;this.failed=false;this.track=null;if(this.instance){this.instance.destroy();this.instance=null;}this.container.replaceChildren();this.pause.disabled=this.seek.disabled=true;this.time.textContent='0:00 / —';this.seek.value=0;}
    async play(track) {
      this.stop();this.track=track;this.position=0;
      this.variants=(track.playback_variants?.length?track.playback_variants:[{video_id:track.video_id}]).slice();
      this.variants.sort((a,b)=>Number(a.embeddable===false||a.age_restricted||a.available===false)-Number(b.embeddable===false||b.age_restricted||b.available===false));
      await this.mount(this.generation);
    }
    async mount(generation) {
      const variant=this.variants[this.position]; if(!variant||generation!==this.generation)return;
      this.videoId=variant.video_id;this.onVideo?.(this.videoId);
      if(variant.available===false||variant.embeddable===false||variant.age_restricted){
        this.fail(variant.age_restricted?'This video requires age verification on YouTube.':'YouTube reports this upload unavailable or blocked for embedded playback.',generation,variant.age_restricted?undefined:150);return;
      }
      this.setStatus('Loading YouTube…');
      try {
        await loadAPI();if(generation!==this.generation)return;
        const iframe=document.createElement('iframe');iframe.id='forge-youtube';iframe.title='YouTube: '+this.track.title;
        iframe.allow='autoplay; encrypted-media; picture-in-picture; fullscreen';iframe.allowFullscreen=true;
        iframe.referrerPolicy='strict-origin-when-cross-origin';
        iframe.src='https://www.youtube.com/embed/'+encodeURIComponent(this.videoId)+'?'+new URLSearchParams({enablejsapi:1,origin:location.origin,widget_referrer:location.href,autoplay:1,playsinline:1,controls:1,rel:0});
        this.container.replaceChildren(iframe);
        this.instance=new YT.Player(iframe,{events:{
          onReady:event=>{if(generation!==this.generation)return;this.ready=true;this.pause.disabled=this.seek.disabled=false;this.setStatus('Ready — press Play if your browser blocks autoplay.');event.target.playVideo();},
          onStateChange:event=>{if(generation!==this.generation)return;this.state=event.data;this.failed=false;
            this.pause.textContent=event.data===1?'Ⅱ Pause':'▶ Play';
            this.setStatus(({1:'Playing',2:'Paused',3:'Buffering…',5:'Ready — press Play',0:'Finished'})[event.data]||'Ready — press Play');
            if(event.data===0)this.onEnded?.();this.tick();},
          onAutoplayBlocked:()=>{if(generation===this.generation)this.setStatus('Autoplay was blocked. Press Play in the video or the Play button.');},
          onError:event=>{if(generation===this.generation)this.fail((errors[event.data]||'YouTube playback failed.')+' (YouTube error '+event.data+')',generation,event.data);}
        }});
      } catch(error){if(generation===this.generation)this.fail(error.message,generation);}
    }
    fail(reason,generation,errorCode) {
      if(generation!==this.generation)return;
      generation=++this.generation; // Ignore late events from the failed iframe after destroy.
      this.ready=false;this.failed=true;this.pause.disabled=this.seek.disabled=true;
      if(this.instance){this.instance.destroy();this.instance=null;}
      this.container.replaceChildren();
      if(this.position+1<this.variants.length){this.position++;this.setStatus('Trying another verified upload of this recording…');this.mount(generation);return;}
      const card=document.createElement('div');card.className='playback-fallback';
      const title=document.createElement('strong');title.textContent=this.track.title;
      const artist=document.createElement('p');artist.textContent=this.track.artist||'Artist unverified';
      const note=document.createElement('p');note.textContent='Use “Play on YouTube” to play this upload in your default browser, or choose Next.';
      card.append(title,artist,note);this.container.appendChild(card);
      this.setStatus(reason);this.time.textContent='— / '+(this.variants[this.position].duration?clock(this.variants[this.position].duration):'—');
      // Configuration/network errors and age checks cannot be fixed by trying many uploads.
      if(!this.variants[this.position].age_restricted && [100,101,150].includes(errorCode))this.onUnavailable?.(this.track,this.videoId,reason);
    }
    tick(){if(!this.ready||!this.instance)return;const duration=this.instance.getDuration?.()||0,current=this.instance.getCurrentTime?.()||0;
      this.time.textContent=clock(current)+' / '+(duration?clock(duration):'—');this.seek.max=duration||1;
      if(document.activeElement!==this.seek)this.seek.value=current;
    }
    currentTime(){return this.ready?Math.floor(this.instance.getCurrentTime?.()||0):0;}
  }
  return {Player,clock,errors};
})();
if(typeof module!=='undefined')module.exports=ForgePlayback;
