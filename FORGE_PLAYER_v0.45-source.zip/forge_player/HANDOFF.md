# Forge Player 0.45 engineering handback — 2026-10-22

Status: 0.45 playback and automatic local curation patch. Read-only Google login/import are verified. The owner confirmed Death Grips playback in Opera and then confirmed that Mac Miller — Avian plays after automatic alternate-upload recovery. Public-release policy review and live playlist publishing remain pending.

## 0.45 changes and verification

- Read official YouTube category, topic, availability, duration and artist-credit metadata for the existing 980 videos. At refresh: 630 music recordings, 352 identified artist credits, 349 review items, and 11 additional automatic local playlists. Existing owner corrections and playlist choices were preserved. Counts can change with later curation.
- Genres come from explicit YouTube topic URLs; the generic Music category does not invent a subgenre. Broad topics can overlap and do not establish fine genres such as Breakcore. Source/confidence is visible.
- Artist credits use auto-generated distribution metadata or agreement between the video title credit and artist channel. Uploaders are kept separately. Unknown artists remain unknown; no generic channel is silently promoted to performer.
- Visible official IFrame API player now has play/pause, seeking, actual playback timestamps, auto-next, proper origin/referrer identification, a direct Play action in Library, and meaningful error states. Takeout is not required to play.
- On an eligible failed upload (errors 100/101/150), automatically search for another upload. Only matching artist/title, compatible duration, and matching version labels qualify for automatic trials. At most three candidates are tried; results are cached for the browser session. No history is merged or overwritten. The displayed alternate uploader makes the substitution visible.
- Age-restricted content is sent to normal YouTube viewing; this patch does not bypass age gates. Player configuration/network failures do not trigger a search loop. Manual Find another upload and Play on YouTube remain available.
- Live metadata may say embeddable even when a specific browser/viewer receives error 150. In-app browser tests returned 150 for the tested songs and correctly exhausted alternatives. The owner separately verified Death Grips in Opera and verified Avian after automatic alternate recovery. This is not a claim that every upload will play everywhere.
- Schema 5 migration and pre-patch source/database backups preserve the earlier state. Runtime remains Python standard library plus the normal browser; no new downloaded software, firmware, or subscription is required.
- 34 Python tests pass, plus offline JavaScript checks for playback controls, timestamp, error fallback, variant ranking and stale load cancellation. Official live searches returned alternatives for Avian.

## Earlier live connection result

- The owner completed Google consent in their default Windows browser. Forge verified the returned YouTube channel through the official API and stored the token with Windows DPAPI. Reloading the interface retained Connected status.
- The first callback reached Google successfully but channel verification returned `403 accessNotConfigured`. With the owner's approval, YouTube Data API v3 was enabled in the existing project. A fresh sign-in succeeded. Forge now explains this error on the callback page with a link to Connections.
- The first real likes import returned **980 videos**, 980 new local like observations, and 980 separate recording entries awaiting review. This is a bounded API observation, not a complete lifetime account export.
- No real Takeout history has been imported into this new working library: zero observed listening events, zero calculated Favorites. No fabricated history or genre assignments.
- Local quota ledger: 24 estimated units after connection attempts and the first likes import. This does not measure other clients sharing the Google project. No remote playlist writes were made. Publishing permission has not been granted.
- The original v0.1 folder/database in Downloads is preserved. The new app uses its own local database and port 8766.

## Files and decisions

| File | Change and purpose |
| --- | --- |
| `legacy.py`, `schema.sql`, `static/v01-reference.html` | Preserve the original importer helpers, schema and visual reference. |
| `library.py`, `migration.sql` | Versioned migrations with SQLite backups; recordings retain original video links/events; manual genres, source/confidence, flexible playlists, override rules, Favorites threshold, merge/split/review undo and analytics. |
| `importer.py` | Incremental JSON/HTML parsing, bounded ZIP reads without extraction, content fingerprints, event identities/provenance and persistent audit reports. |
| `classification.py` | Evidence-based broad topics, conservative artist credits, automatic local mix creation, and alternate-upload matching. |
| `static/player.js` | Official visible YouTube player, real time/seek controls, error reporting, and bounded variant handling. |
| `youtube.py` | Official Desktop OAuth with state/PKCE, DPAPI storage, capped likes import, separate metadata cache, quota ledger, preview/approval and checkpointed add-only publishing. |
| `forge.py` | CLI and loopback API with Host/Origin/CSRF checks; system-browser login; actionable callback errors; CSV export. |
| `static/index.html`, `static/app.js`, `static/style.css` | Data-driven library, review and curation, Favorites control, analytics, Connections and publishing controls, preserving the violet/blue palette and basic player. |
| `tests/` | Synthetic importer/library cases, OAuth/security, DPAPI, mocked publishing and a reproducible volume benchmark. |
| `START_FORGE_PLAYER.bat`, `README.md` | Windows launcher and operator instructions, including restore and Google setup. |

Membership is organized by recording. Playback prefers variants not reported as blocked, then handles actual player errors. Existing verified video variants can be tried, followed by conservative search candidates. Search candidates are session-only playback substitutions; they are never silently merged into the canonical recording. Manual corrections remain authoritative. Automatic metadata stays in a separate expiring cache and does not overwrite manual artist/title/genre choices.

Same-timestamp multiplicity is retained within a source and overlaps use maximum observed multiplicity across files. With no unique upstream event ID, two independent identical starts in separate files can be indistinguishable. Untimed items retain explicit uncertainty. See import reports; do not interpret these counts as completed listens or listening minutes.

## Verification

- All 25 automated tests passed on Windows, including real DPAPI encryption/decryption and local HTTP origin/CSRF tests. Google write tests use mocks and make no production mutations.
- Synthetic benchmark: 25,000 events / 5,000 recordings, five recent plays each; 5,000 qualifying Favorites. Import 6.50 seconds, re-import 4.46 seconds with **zero new events**, summary 0.188 seconds and 50-row Favorites query 0.145 seconds on this machine. See `evidence/synthetic-benchmark.json`; timings vary by machine.
- Live channel verification and read-only import succeeded; login state survived page reload. The owner performed the browser consent step.
- Browser checks used the available in-app browser. Native Opera/Chrome UI automation was not available; the owner's successful default-browser consent is not a full Opera/Chrome UI regression test.

## Remaining work / limits for Echo

- Real Takeout import and owner review remain pending; synthetic fixtures are not evidence of the owner's historical listening data.
- Restored and implemented in 0.45: artist identification from supported YouTube metadata, artist/uploader separation, automatic broad genre detection, automatic local playlist creation/membership, and playback fallback across suitable uploads. A full external artist-alias/collaboration identity database and fine-genre enrichment remain optional future extensions; unknown evidence stays visible.
- API metadata is kept separate and hidden after 30 days, but a complete automated expiry/refresh/deletion lifecycle and public privacy/YouTube-policy review are still required before redistribution. Disconnect removes cached video metadata and API like observations; derived sync plans/audits need a final retention review.
- Publishing is add-only. There is no remote deletion UI or automatic removal. Preview reports remote-only items retained and unverified availability. No account publishing permission or production write was needed to prove the mocked workflow.
- Worker pacing, quota pause/resume and uncertain-outcome reconciliation exist. Automatic exponential backoff is not implemented; failures pause for explicit recovery. Never blindly retry an uncertain playlist creation.
- Full UI testing in Opera and Chrome, refreshed/expired-token live tests and a real approved publishing trial remain unverified.
- Current analytics aggregate genres and UTC days; they do not provide a full genre-by-day time-series explorer.
- The owner explicitly expanded the player scope for 0.45: auto-next, timestamps, controls and bounded automatic upload fallback now exist. Listening-event recording, richer shuffle, skip weighting and durable owner-approved replacement mappings remain future work. Search fallback does not invent listening history.

## Running and restoring

Launch `START_FORGE_PLAYER.bat` and open http://127.0.0.1:8766/. The README covers import, curation, dry run and disconnect. Keep `.private/`, SQLite files, backups, logs and real evidence screenshots private. The source ZIP must exclude them.

Before using an existing database, keep a separate copy. Migration also creates a timestamped `.bak` using SQLite's backup API. To roll back, stop Forge, preserve the current database separately, and copy the pre-migration backup to the database path you intend to open with v0.1. Do not point v0.1 at a new-version database as a rollback substitute.
