"""Versioned local library. Original video/event tables remain readable by v0.1."""
import hashlib
import json
import re
import sqlite3
import unicodedata
import uuid
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULTS = {'favorite_threshold': 5, 'liked_favorites': False}
FAMILIES = {'Jungle':'ELECTRONIC','Breakcore':'ELECTRONIC','Vaporwave':'ELECTRONIC',
 'Indie Rock':'ROCK','Punk':'ROCK','Classic Rock':'ROCK','Rock':'ROCK',
 'Hip-Hop':'HIPHOP','90s Indie':'HIPHOP','Phonk':'HIPHOP',
 'Electronic':'ELECTRONIC','Pop':'POP','R&B':'RNB','Soul':'SOUL','Jazz':'JAZZ',
 'Blues':'BLUES','Classical':'CLASSICAL','Country':'COUNTRY','Reggae':'REGGAE',
 'Metal':'ROCK','Indie':'INDIE','Latin music':'LATIN','Asian music':'ASIAN',
 'Christian music':'CHRISTIAN'}

def now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')

def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()

def connect(path):
    con = sqlite3.connect(str(path), timeout=30)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    version = con.execute('PRAGMA user_version').fetchone()[0]
    if version > 5:
        con.close()
        raise ValueError('Database is newer than this app; use the newer version.')
    if version == 5:
        return con
    if version == 4:
        backup=Path(str(path)+'.pre-v045-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.bak')
        with closing(sqlite3.connect(backup)) as dest: con.backup(dest)
        con.execute('CREATE TABLE api_classification (video_id TEXT PRIMARY KEY REFERENCES tracks(video_id), data TEXT NOT NULL, fetched_at TEXT NOT NULL)')
        con.execute('CREATE TABLE genre_locks (recording_id TEXT PRIMARY KEY REFERENCES recordings(id))')
        con.execute('INSERT INTO genre_locks SELECT id FROM recordings WHERE manual_lock=1 UNION SELECT recording_id FROM recording_genres WHERE manual_lock=1')
        con.executemany('INSERT OR IGNORE INTO genres VALUES(?,?)',FAMILIES.items())
        con.execute('PRAGMA user_version=5'); con.commit()
        return con
    if version == 3:
        backup=Path(str(path)+'.pre-cache-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.bak')
        if backup.exists(): raise ValueError('Backup exists; migration stopped.')
        with closing(sqlite3.connect(backup)) as dest: con.backup(dest)
        con.executescript('BEGIN IMMEDIATE; CREATE TABLE api_video_cache (video_id TEXT PRIMARY KEY REFERENCES tracks(video_id),title TEXT,uploader TEXT,fetched_at TEXT NOT NULL); PRAGMA user_version=4; COMMIT;')
        con.close()
        return connect(path)
    existed = con.execute("SELECT 1 FROM sqlite_master WHERE name='tracks'").fetchone()
    if existed:
        backup = Path(str(path) + '.pre-v02-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.bak')
        if backup.exists():
            raise ValueError('Backup already exists; migration stopped safely.')
        with closing(sqlite3.connect(backup)) as dest:
            con.backup(dest)
        print('Migration backup: ' + str(backup))
    try:
        con.executescript('BEGIN IMMEDIATE;\n' + (ROOT/'schema.sql').read_text() + '\n' + (ROOT/'migration.sql').read_text())
        for key, value in DEFAULTS.items():
            con.execute('INSERT INTO settings VALUES(?,?)', (key,json.dumps(value)))
        for i,(key,color,kind,rule) in enumerate([
            ('ELECTRONIC','#00edff','hybrid','ELECTRONIC'),('ROCK','#fff239','hybrid','ROCK'),
            ('HIPHOP','#bd8cff','hybrid','HIPHOP'),('FAVORITES','#ff36d9','hybrid','favorites'),
            ('EMOTIONAL','#35ffc2','manual','')]):
            con.execute('INSERT INTO playlists(id,name,color,kind,rule,position) VALUES(?,?,?,?,?,?)',
                        (key,'HIP-HOP' if key=='HIPHOP' else key,color,kind,rule,i))
        con.executemany('INSERT INTO genres VALUES(?,?)', FAMILIES.items())
        # Preserve old user choices, but deliberately replace automatic Favorites policy.
        con.execute("INSERT INTO memberships SELECT 'FAVORITES',video_id,favorite_override FROM tracks WHERE favorite_override IS NOT NULL")
        con.execute("INSERT INTO memberships SELECT 'EMOTIONAL',video_id,1 FROM tracks WHERE is_emotional=1")
        con.execute("INSERT INTO like_observations SELECT video_id,'legacy-import',CURRENT_TIMESTAMP,'imported; unverified-current' FROM tracks WHERE is_liked=1")
        counts = {}
        for event in con.execute('SELECT * FROM listens ORDER BY rowid').fetchall():
            if event['played_at']:
                stamp = normalize_time(event['played_at'])
                base = event['video_id'] + '|' + (stamp or event['played_at'])
                counts[base] = counts.get(base,0) + 1
                con.execute('INSERT OR IGNORE INTO event_identity VALUES(?,?)',
                            (digest(base+'|'+str(counts[base])),event['event_key']))
        con.commit()
    except Exception:
        con.rollback()
        con.close()
        raise
    return con

def normalize_time(value):
    if not value:
        return None
    raw = str(value).strip()
    try:
        dt = datetime.fromisoformat(raw.replace('Z','+00:00'))
        if dt.tzinfo is None:
            return None
        return dt.astimezone(timezone.utc).isoformat(timespec='microseconds')
    except ValueError:
        pass
    # Only explicit offsets/zones are trusted. Unknown/localized dates remain untimed.
    zones = {'UTC':0,'GMT':0,'EST':-5,'EDT':-4,'PST':-8,'PDT':-7}
    parts = raw.rsplit(' ',1)
    if len(parts)!=2 or parts[1] not in zones:
        return None
    for fmt in ('%b %d, %Y, %I:%M:%S %p','%b %d, %Y, %I:%M %p','%B %d, %Y, %I:%M:%S %p','%d %b %Y, %H:%M:%S'):
        try:
            dt=datetime.strptime(parts[0],fmt).replace(tzinfo=timezone(timedelta(hours=zones[parts[1]])))
            return dt.astimezone(timezone.utc).isoformat(timespec='microseconds')
        except ValueError:
            pass
    return None

def settings(con):
    return {r['key']:json.loads(r['value']) for r in con.execute('SELECT * FROM settings')}

def set_settings(con, data):
    threshold=data.get('favorite_threshold')
    liked=data.get('liked_favorites')
    if type(threshold) is not int or not 1 <= threshold <= 50 or type(liked) is not bool:
        raise ValueError('Choose a whole number 1–50 and a liked-songs preference.')
    with con:
        con.executemany('UPDATE settings SET value=? WHERE key=?',[(json.dumps(threshold),'favorite_threshold'),(json.dumps(liked),'liked_favorites')])
    return settings(con)

def playlists(con, include_archived=False):
    return [dict(r) for r in con.execute('SELECT * FROM playlists '+('' if include_archived else 'WHERE archived=0 ')+'ORDER BY position,id')]

def save_playlist(con, data):
    ident=data.get('id') or uuid.uuid4().hex
    old=con.execute('SELECT * FROM playlists WHERE id=?',(ident,)).fetchone()
    name=str(data.get('name','')).strip()
    color=data.get('color','#bd8cff')
    kind=data.get('kind','manual')
    rule=data.get('rule','')
    if not name or len(name)>100 or not re.fullmatch(r'#[0-9A-Fa-f]{6}',color):
        raise ValueError('Playlist needs a name (1–100 characters) and a hex color.')
    if kind not in ('manual','smart','hybrid') or rule not in ('','favorites','music',*FAMILIES.values(),*FAMILIES):
        raise ValueError('Unsupported playlist rule.')
    position=data.get('position',len(playlists(con,True)))
    if type(position) is not int or not 0<=position<=100000:
        raise ValueError('Invalid playlist order.')
    archived=int(bool(data.get('archived',False)))
    if ident in ('FAVORITES','EMOTIONAL') and old:
        kind,rule=old['kind'],old['rule']
    with con:
        con.execute('INSERT INTO playlists VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,kind=excluded.kind,rule=excluded.rule,position=excluded.position,archived=excluded.archived',
                    (ident,name,color,kind,rule,position,archived))
    return {'id':ident}

def records(con):
    end=now()
    since=(datetime.now(timezone.utc)-timedelta(days=90)).isoformat(timespec='microseconds')
    rows=con.execute('''SELECT r.*, min(t.video_id) video_id, max(t.music_status='music') music,
       min(t.music_status='not_music') nonmusic, max(t.is_liked) is_liked,
       max(t.category_source='manual') manual_status,
       group_concat(DISTINCT t.category) categories, group_concat(DISTINCT t.artist) uploader,
       sum(coalesce(c.plays_all,0)) plays_all, sum(coalesce(c.plays_90,0)) plays_90,
       sum(coalesce(s.n,0)) skips_all, count(*) variants
       FROM recordings r JOIN video_recording_links v ON v.recording_id=r.id JOIN tracks t ON t.video_id=v.video_id
       LEFT JOIN (SELECT video_id,count(*) plays_all,sum(played_at>=? AND played_at<=?) plays_90 FROM listens GROUP BY video_id) c ON c.video_id=t.video_id
       LEFT JOIN (SELECT video_id,count(*) n FROM skips GROUP BY video_id) s ON s.video_id=t.video_id
       GROUP BY r.id''',(since,end)).fetchall()
    tags={}
    for r in con.execute('SELECT * FROM recording_genres'):
        tags.setdefault(r['recording_id'],[]).append(dict(r))
    genre_locks={r[0] for r in con.execute('SELECT recording_id FROM genre_locks')}
    overrides={(r['playlist_id'],r['recording_id']):r['included'] for r in con.execute('SELECT * FROM memberships')}
    defs=playlists(con)
    prefs=settings(con)
    cache={r['video_id']:dict(r) for r in con.execute("SELECT * FROM api_video_cache WHERE fetched_at>=?",((datetime.now(timezone.utc)-timedelta(days=30)).isoformat(),))}
    classification={r['video_id']:json.loads(r['data']) for r in con.execute('SELECT * FROM api_classification WHERE fetched_at>=?',((datetime.now(timezone.utc)-timedelta(days=30)).isoformat(),))}
    variants={}
    for v in con.execute('SELECT * FROM video_recording_links'): variants.setdefault(v['recording_id'],[]).append(v['video_id'])
    out=[]
    for row in rows:
        r=dict(row); rid=r['id']; r['recording_id']=rid
        choices=variants[rid]
        choices.sort(key=lambda vid:(classification.get(vid,{}).get('embeddable') is False or classification.get(vid,{}).get('age_restricted',False),vid))
        r['video_id']=choices[0]
        detected=[classification[v] for v in choices if v in classification]
        metadata=classification.get(r['video_id'],{})
        r['playback_variants']=[{'video_id':v,**{k:classification.get(v,{}).get(k) for k in ('embeddable','age_restricted','duration','available')}} for v in choices]
        cached=cache.get(r['video_id'])
        if cached:
            if not r['manual_lock'] and r['title'].startswith('Video '): r['title']=cached['title'] or r['title']
            if not r['uploader']: r['uploader']=cached['uploader'] or ''
        r['metadata_source']='YouTube API cache (30 days)' if cached else 'Takeout / local curation'
        r['music_status']='music' if r['music'] else ('not_music' if r['nonmusic'] else 'review')
        r['genres']=tags.get(rid,[])
        if not r['manual_status'] and any(d.get('music') for d in detected):
            r['music']=1; r['music_status']='music'
        if not r['manual_lock']:
            if metadata.get('artist'): r['artist']=metadata['artist']; r['artist_source']=metadata['artist_source']
            if metadata.get('song_title'): r['title']=metadata['song_title']
        # Explicit genre corrections (including clearing all tags) override API topics.
        if rid not in genre_locks and not r['genres']:
            auto_tags=set(g for d in detected for g in d.get('genres',[]))
            r['genres']=[{'genre':g,'source':'YouTube topic','confidence':0.8,'manual_lock':0} for g in sorted(auto_tags)]
        r['playback']=metadata
        r['category']=r['categories'].split(',')[0]
        r['memberships']=[]
        r['overrides']={pid:value for (pid,recording),value in overrides.items() if recording==rid}
        fav=overrides.get(('FAVORITES',rid))
        auto=r['plays_90']>=prefs['favorite_threshold'] or (prefs['liked_favorites'] and r['is_liked'])
        r['is_favorite']=int(r['music'] and (fav==1 or (fav is None and auto)))
        r['favorite_override']=fav
        r['favorite_reason']=('Manual favorite' if fav==1 else 'Excluded manually' if fav==0 else
            'Liked (if enabled)' if prefs['liked_favorites'] and r['is_liked'] else
            f"{r['plays_90']} plays/90d {'>=' if auto else '<'} {prefs['favorite_threshold']}")
        r['is_emotional']=overrides.get(('EMOTIONAL',rid),0)
        families=set(r['categories'].split(',')) | {FAMILIES.get(t['genre']) for t in r['genres']}
        for p in defs:
            override=overrides.get((p['id'],rid))
            eligible=(r['is_favorite'] if p['rule']=='favorites' else bool(r['music']) if p['rule']=='music' else p['rule'] in families or p['rule'] in {t['genre'] for t in r['genres']}) if p['kind']!='manual' else False
            if r['music'] and (override==1 or (override is None and eligible)):
                r['memberships'].append(p['id'])
        out.append(r)
    return out

def tracks_list(con, playlist='ALL', query='', sort='popular', offset=0, limit=100):
    rows=records(con)
    if playlist=='REVIEW': rows=[r for r in rows if r['music_status']=='review']
    elif playlist=='UNSORTED': rows=[r for r in rows if r['music'] and not r['genres'] and r['categories']=='UNSORTED']
    elif playlist!='ALL': rows=[r for r in rows if playlist in r['memberships']]
    if query: rows=[r for r in rows if query.casefold() in (r['title']+' '+r['artist']+' '+r['uploader']+' '+r['video_id']).casefold()]
    rows.sort(key=lambda r: (r['title'].casefold(),) if sort=='alpha' else (-(r['plays_all'] if sort=='lifetime' else r['skips_all'] if sort=='skipped' else r['plays_90']),-r['plays_all'],r['title'].casefold()))
    return {'total':len(rows),'tracks':rows[max(0,offset):max(0,offset)+min(max(1,limit),20000)]}

def summary(con):
    rows=records(con); end=now(); since=(datetime.now(timezone.utc)-timedelta(days=90)).isoformat()
    artists={}
    for r in rows:
        if r['music'] and r['artist']: artists[r['artist']]=artists.get(r['artist'],0)+r['plays_90']
    return {'songs':con.execute('SELECT count(*) FROM tracks').fetchone()[0], 'recordings':len(rows),
     'likes':con.execute('SELECT count(*) FROM tracks WHERE is_liked=1').fetchone()[0],
     'total_events':con.execute('SELECT count(*) FROM listens').fetchone()[0],
     'recent_events':con.execute('SELECT count(*) FROM listens WHERE played_at>=? AND played_at<=?',(since,end)).fetchone()[0],
     'timeless_events':con.execute('SELECT count(*) FROM listens WHERE played_at IS NULL').fetchone()[0],
     'skips':con.execute('SELECT count(*) FROM skips').fetchone()[0],
     'music_tracks':sum(bool(r['music']) for r in rows),'review_tracks':sum(r['music_status']=='review' for r in rows),
     'playlists':{p['id']:sum(p['id'] in r['memberships'] for r in rows) for p in playlists(con)},
     'top_artists':[{'artist':a,'plays':n} for a,n in sorted(artists.items(),key=lambda p:-p[1])[:8]],
     'recent_days':[dict(r) for r in con.execute('SELECT substr(played_at,1,10) day,count(*) plays FROM listens WHERE played_at>=? AND played_at<=? GROUP BY day ORDER BY day',(since,end))],
     'settings':settings(con),'playlist_definitions':playlists(con),
     'reports':[json.loads(r[0]) for r in con.execute('SELECT report FROM import_reports ORDER BY id DESC LIMIT 10')]}

def edit_snapshot(con):
    tables=('recordings','video_recording_links','recording_genres','memberships','genre_locks')
    result={t:[dict(r) for r in con.execute('SELECT * FROM '+t+' ORDER BY rowid')] for t in tables}
    result['track_curation']=[dict(r) for r in con.execute('SELECT video_id,music_status,category,category_source FROM tracks ORDER BY video_id')]
    return result

def audit_edit(con, action, before):
    con.execute('INSERT INTO edits(action,before_state,after_state) VALUES(?,?,?)',
                (action,json.dumps(before),json.dumps(edit_snapshot(con))))

def update_recording(con, data, commit=True):
    rid=data.get('recording_id')
    if not rid and data.get('video_id'):
        row=con.execute('SELECT recording_id FROM video_recording_links WHERE video_id=?',(data['video_id'],)).fetchone()
        rid=row[0] if row else None
    if not con.execute('SELECT 1 FROM recordings WHERE id=?',(rid,)).fetchone(): raise ValueError('Recording not found')
    from contextlib import nullcontext
    with con if commit else nullcontext():
        for field in ('title','artist'):
            if field in data:
                value=data[field]
                if not isinstance(value,str) or not value.strip() or len(value)>350: raise ValueError('Invalid '+field)
                con.execute('UPDATE recordings SET '+field+'=?,manual_lock=1,artist_source=? WHERE id=?',(value.strip(),'manual',rid))
        if 'music_status' in data:
            if data['music_status'] not in ('review','music','not_music'): raise ValueError('Invalid status')
            con.execute('UPDATE tracks SET music_status=?,category_source=? WHERE video_id IN (SELECT video_id FROM video_recording_links WHERE recording_id=?)',(data['music_status'],'manual',rid))
        if 'genres' in data:
            if not isinstance(data['genres'],list) or any(g not in FAMILIES for g in data['genres']): raise ValueError('Unknown genre')
            con.execute('DELETE FROM recording_genres WHERE recording_id=?',(rid,))
            con.execute('INSERT OR IGNORE INTO genre_locks VALUES(?)',(rid,))
            con.executemany('INSERT INTO recording_genres VALUES(?,?,?,1,1)',[(rid,g,'manual') for g in set(data['genres'])])
            con.execute("UPDATE tracks SET category='UNSORTED',category_source='manual' WHERE video_id IN (SELECT video_id FROM video_recording_links WHERE recording_id=?)",(rid,))
        members=data.get('memberships',{})
        if 'favorite_override' in data: members['FAVORITES']=data['favorite_override']
        if 'is_emotional' in data: members['EMOTIONAL']=data['is_emotional']
        for pid,value in members.items():
            if value not in (None,0,1) or not con.execute('SELECT 1 FROM playlists WHERE id=?',(pid,)).fetchone(): raise ValueError('Invalid playlist override')
            if value is None: con.execute('DELETE FROM memberships WHERE playlist_id=? AND recording_id=?',(pid,rid))
            else: con.execute('INSERT OR REPLACE INTO memberships VALUES(?,?,?)',(pid,rid,value))
    return {'ok':True}

def bulk_review(con, ids, status):
    if not isinstance(ids,list) or not 1<=len(ids)<=100 or status not in ('music','not_music','review'):
        raise ValueError('Choose 1–100 recordings and a music status.')
    before=edit_snapshot(con)
    with con:
        for rid in set(ids): update_recording(con,{'recording_id':rid,'music_status':status},commit=False)
        audit_edit(con,'bulk music review',before)
    return {'updated':len(set(ids))}

def merge(con, target, source, verified=False):
    if not verified or source==target: raise ValueError('Confirm these are the same recording first.')
    if con.execute('SELECT count(*) FROM recordings WHERE id IN (?,?)',(target,source)).fetchone()[0]!=2: raise ValueError('Missing recording')
    # Conflicting exclusions must be resolved by the owner, never silently overwritten.
    if con.execute('SELECT 1 FROM memberships a JOIN memberships b ON a.playlist_id=b.playlist_id WHERE a.recording_id=? AND b.recording_id=? AND a.included!=b.included',(target,source)).fetchone():
        raise ValueError('Resolve conflicting playlist include/exclude choices before merging.')
    before=edit_snapshot(con)
    with con:
        con.execute('UPDATE video_recording_links SET recording_id=?,evidence=? WHERE recording_id=?',(target,'user verified same recording',source))
        con.execute('INSERT OR IGNORE INTO recording_genres SELECT ?,genre,source,confidence,manual_lock FROM recording_genres WHERE recording_id=?',(target,source))
        con.execute('INSERT OR IGNORE INTO genre_locks SELECT ? FROM genre_locks WHERE recording_id=?',(target,source))
        con.execute('INSERT OR IGNORE INTO memberships SELECT playlist_id,?,included FROM memberships WHERE recording_id=?',(target,source))
        audit_edit(con,'merge',before)
    return {'ok':True}

def split(con, video_id):
    old=con.execute('SELECT r.* FROM recordings r JOIN video_recording_links v ON r.id=v.recording_id WHERE v.video_id=?',(video_id,)).fetchone()
    if not old: raise ValueError('Unknown video')
    if con.execute('SELECT count(*) FROM video_recording_links WHERE recording_id=?',(old['id'],)).fetchone()[0]<2: raise ValueError('Already a separate recording')
    before=edit_snapshot(con); rid=uuid.uuid4().hex
    with con:
        con.execute('INSERT INTO recordings VALUES(?,?,?,?,?)',(rid,old['title'],old['artist'],'manual split',1))
        con.execute('UPDATE video_recording_links SET recording_id=?,evidence=? WHERE video_id=?',(rid,'manual split',video_id))
        con.execute('INSERT INTO recording_genres SELECT ?,genre,source,confidence,manual_lock FROM recording_genres WHERE recording_id=?',(rid,old['id']))
        con.execute('INSERT OR IGNORE INTO genre_locks SELECT ? FROM genre_locks WHERE recording_id=?',(rid,old['id']))
        con.execute('INSERT INTO memberships SELECT playlist_id,?,included FROM memberships WHERE recording_id=?',(rid,old['id']))
        audit_edit(con,'split',before)
    return {'ok':True}

def undo(con):
    row=con.execute('SELECT * FROM edits WHERE undone=0 ORDER BY id DESC LIMIT 1').fetchone()
    if not row: raise ValueError('No review, merge or split to undo')
    if edit_snapshot(con)!=json.loads(row['after_state']): raise ValueError('Library changed after this action; undo would overwrite newer edits. Split manually instead.')
    before=json.loads(row['before_state'])
    with con:
        for table in ('genre_locks','memberships','recording_genres','video_recording_links','recordings'): con.execute('DELETE FROM '+table)
        for table in ('recordings','video_recording_links','recording_genres','memberships','genre_locks'):
            for item in before[table]:
                con.execute('INSERT INTO '+table+'('+','.join(item)+') VALUES('+','.join('?' for _ in item)+')',tuple(item.values()))
        for item in before.get('track_curation',[]):
            con.execute('UPDATE tracks SET music_status=?,category=?,category_source=? WHERE video_id=?',
                        (item['music_status'],item['category'],item['category_source'],item['video_id']))
        con.execute('UPDATE edits SET undone=1 WHERE id=?',(row['id'],))
    return {'ok':True}

def candidates(con):
    groups={}
    for r in records(con):
        # Suggestions only, never auto-merge or strip version markers.
        if r['artist']:
            key=unicodedata.normalize('NFKC',r['artist']+'|'+r['title']).casefold().strip()
            groups.setdefault(key,[]).append({'id':r['id'],'title':r['title'],'artist':r['artist'],'video_id':r['video_id']})
    return [v for v in groups.values() if len(v)>1][:100]

def analytics(con):
    rows=records(con)
    genre_counts={}
    for r in rows:
        for tag in r['genres']:
            genre_counts[tag['genre']]=genre_counts.get(tag['genre'],0)+r['plays_90']
    return {'top_recordings':[{'title':r['title'],'artist':r['artist'],'plays':r['plays_90']} for r in sorted(rows,key=lambda r:-r['plays_90'])[:20]],
            'genre_plays':[{'genre':g,'plays':n} for g,n in sorted(genre_counts.items(),key=lambda x:-x[1])],
            'note':'Multi-genre recordings contribute to each selected genre; totals across genres can overlap.'}
